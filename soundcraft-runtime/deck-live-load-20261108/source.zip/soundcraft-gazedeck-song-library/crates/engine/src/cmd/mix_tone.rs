//! Atomic, narrowly scoped tone presets: three EQ gains and three FX wet mixes/bypasses.
use super::{CommandSpec, always, bad};
use crate::{Engine, Result, TransportRequest, cmd};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use soundcraft_dsp::PluginInfo;
use soundcraft_model::{AutomationMode, Insert, Track, TrackId, TrackKind};
use std::collections::{BTreeMap, BTreeSet};

const INSPECT: &str = "mix.tone.inspect";
const APPLY: &str = "mix.tone.apply";
const RESTORE: &str = "mix.tone.restore";
const GAINS: [&str; 3] = ["low_shelf_gain", "mid_gain", "high_shelf_gain"];

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!(query "mix.tone.inspect", "Inspect Tone Parameters", [], None,
            "{tracks?:[id]} — actual three-band gains and reverb/delay/chorus wet mixes", always, inspect),
        cmd!(query "mix.tone.apply", "Apply Tone Preset", [], None,
            "{epoch,updates:[{track,expectedInserts,tone}]} — atomic 1..2-track tone-only CAS", always, apply),
        cmd!(query "mix.tone.restore", "Restore Tone Parameters", [], None,
            "{epoch,receipt} — consume a native-owned, epoch-scoped tone undo receipt", always, restore),
    ]
}

#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct EqTone {
    enabled: bool,
    low: f64,
    mid: f64,
    high: f64,
}
#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct FxTone {
    enabled: bool,
    amount: f64,
}
#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct Effects {
    reverb: FxTone,
    delay: FxTone,
    chorus: FxTone,
}
#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct Tone {
    eq: EqTone,
    effects: Effects,
}
#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct InsertView {
    slot: usize,
    plugin: String,
    bypass: bool,
    params: BTreeMap<String, f32>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct InspectRequest {
    tracks: Option<Vec<u64>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Update {
    track: u64,
    #[serde(rename = "expectedInserts")]
    expected: Vec<InsertView>,
    tone: Tone,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ApplyRequest {
    epoch: String,
    updates: Vec<Update>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RestoreRequest {
    epoch: String,
    receipt: String,
}

#[derive(Clone, Debug)]
struct Change {
    track: TrackId,
    slot: usize,
    before: Option<Insert>,
    after: Option<Insert>,
}
#[derive(Clone, Debug)]
pub(crate) struct ToneReceipt {
    token: String,
    changes: Vec<Change>,
    effect_owners: BTreeMap<(TrackId, usize), Insert>,
}

fn infos() -> [&'static PluginInfo; 4] {
    [
        &soundcraft_dsp::plugins::eq::EQ7_INFO,
        &soundcraft_dsp::plugins::reverb::ROOM_INFO,
        &soundcraft_dsp::plugins::modulation::DELAY_INFO,
        &soundcraft_dsp::plugins::modulation::CHORUS_INFO,
    ]
}
fn recording(e: &Engine) -> bool {
    e.transport.recording || e.transport_requests.iter().any(|r| matches!(r, TransportRequest::Record))
}
fn reason(e: &Engine, t: &Track) -> &'static str {
    if recording(e) {
        return "Stop recording before editing tone";
    }
    if t.kind != TrackKind::Audio || t.inactive || t.frozen {
        return "Use an active, unfrozen audio track";
    }
    if t.mixer.record_arm || t.mixer.input_monitor {
        return "Turn record arm and input monitoring off";
    }
    if !matches!(t.mixer.automation_mode, AutomationMode::Off | AutomationMode::Read) || t.automation.iter().any(|lane| !lane.points.is_empty()) {
        return "Disable tone automation before editing";
    }
    if t.mixer.inserts.len() > 10 {
        return "Unsupported insert chain length";
    }
    for info in infos() {
        let candidates = t.mixer.inserts.iter().flatten().filter(|i| i.plugin == info.id).collect::<Vec<_>>();
        if candidates.len() > 1 {
            return "Multiple matching tone plugins are ambiguous";
        }
        if let Some(i) = candidates.first()
            && (!i.active
                || i.state.is_some()
                || i.sample.is_some()
                || i.params.iter().any(|(key, value)| !value.is_finite() || !info.param(key).is_some_and(|p| *value >= p.min && *value <= p.max)))
        {
            return "Tone plugin is inactive or has unsupported state/parameters";
        }
    }
    ""
}
fn view(inserts: &[Option<Insert>]) -> Vec<InsertView> {
    inserts
        .iter()
        .enumerate()
        .filter_map(|(slot, i)| i.as_ref().map(|i| InsertView { slot, plugin: i.plugin.clone(), bypass: i.bypass, params: i.params.clone() }))
        .collect()
}
fn effective(insert: Option<&Insert>, info: &PluginInfo, key: &str) -> f64 {
    let Some(param) = info.param(key) else {
        return 0.0;
    };
    let value = insert.and_then(|i| i.params.get(key)).copied().filter(|v| v.is_finite()).unwrap_or(param.default);
    f64::from(value.clamp(param.min, param.max))
}
fn tone(t: &Track) -> Tone {
    let all = infos();
    let find = |info: &PluginInfo| t.mixer.inserts.iter().flatten().find(|i| i.plugin == info.id);
    let eq = find(all[0]);
    let fx = |info: &PluginInfo| {
        let insert = find(info);
        FxTone { enabled: insert.is_some_and(|i| i.active && !i.bypass), amount: effective(insert, info, "mix") / 100.0 }
    };
    Tone {
        eq: EqTone {
            enabled: eq.is_some_and(|i| i.active && !i.bypass),
            low: effective(eq, all[0], GAINS[0]),
            mid: effective(eq, all[0], GAINS[1]),
            high: effective(eq, all[0], GAINS[2]),
        },
        effects: Effects { reverb: fx(all[1]), delay: fx(all[2]), chorus: fx(all[3]) },
    }
}
fn snapshot(e: &Engine, ids: Option<&BTreeSet<TrackId>>) -> Value {
    json!({"version":1,"epoch":e.track_rate_epoch,"tracks":e.session().tracks.iter()
        .filter(|t| t.kind == TrackKind::Audio && ids.is_none_or(|ids| ids.contains(&t.id)))
        .map(|t| { let why = reason(e,t); json!({"track":t.id,"available":why.is_empty(),"reason":why,
            "tone":tone(t),"inserts":view(&t.mixer.inserts)}) }).collect::<Vec<_>>()})
}
fn id(command: &str, value: u64) -> Result<TrackId> {
    if value == 0 || value > (1_u64 << 53) - 1 {
        return Err(bad(command, "track must be a positive safe integer"));
    }
    Ok(TrackId(value))
}
fn inspect(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: InspectRequest = serde_json::from_value(p.clone()).map_err(|why| bad(INSPECT, why.to_string()))?;
    let ids = if let Some(raw) = request.tracks {
        if raw.is_empty() || raw.len() > 64 {
            return Err(bad(INSPECT, "tracks must contain 1..64 ids"));
        }
        let mut ids = BTreeSet::new();
        for raw in raw {
            let id = id(INSPECT, raw)?;
            if !ids.insert(id) || !e.session().track(id).is_some_and(|t| t.kind == TrackKind::Audio) {
                return Err(bad(INSPECT, "duplicate or missing audio track"));
            }
        }
        Some(ids)
    } else {
        None
    };
    Ok(snapshot(e, ids.as_ref()))
}
fn valid(t: &Tone) -> bool {
    [t.eq.low, t.eq.mid, t.eq.high].iter().all(|v| v.is_finite() && (-24.0..=24.0).contains(v))
        && [&t.effects.reverb, &t.effects.delay, &t.effects.chorus].iter().all(|f| f.amount.is_finite() && (0.0..=1.0).contains(&f.amount))
}
fn update_insert(inserts: &mut [Option<Insert>], info: &PluginInfo, enabled: bool, params: &[(&str, f32)]) -> Result<()> {
    let existing = inserts.iter().position(|i| i.as_ref().is_some_and(|i| i.plugin == info.id));
    if existing.is_none() && !enabled {
        return Ok(());
    }
    let slot = existing.or_else(|| inserts.iter().position(Option::is_none)).ok_or_else(|| bad(APPLY, "No free insert slot; no changes applied"))?;
    let target = inserts.get_mut(slot).ok_or_else(|| bad(APPLY, "Invalid insert slot"))?;
    let mut after = target.clone().unwrap_or_else(|| {
        let mut i = Insert::new(info.id);
        i.params = info.params.iter().map(|p| (p.id.to_string(), p.default)).collect();
        i
    });
    after.bypass = !enabled;
    for (key, value) in params {
        // Do not turn implicit factory defaults into unrelated explicit parameters.
        let current = after.params.get(*key).copied().or_else(|| info.param(key).map(|p| p.default));
        if current != Some(*value) {
            after.params.insert((*key).into(), *value);
        }
    }
    *target = Some(after);
    Ok(())
}
fn apply(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: ApplyRequest = serde_json::from_value(p.clone()).map_err(|why| bad(APPLY, why.to_string()))?;
    if request.epoch != e.track_rate_epoch || request.updates.is_empty() || request.updates.len() > 2 {
        return Err(bad(APPLY, "epoch changed or updates must contain 1..2 tracks"));
    }
    let mut seen = BTreeSet::new();
    let mut changes = Vec::new();
    for update in request.updates {
        let track_id = id(APPLY, update.track)?;
        if !seen.insert(track_id) || !valid(&update.tone) {
            return Err(bad(APPLY, "Duplicate track or invalid tone"));
        }
        let t = e.session().track(track_id).ok_or_else(|| bad(APPLY, "Missing audio track"))?;
        let why = reason(e, t);
        if !why.is_empty() {
            return Err(bad(APPLY, why));
        }
        if update.expected != view(&t.mixer.inserts) {
            return Err(bad(APPLY, "Insert chain changed; reopen preview"));
        }
        let mut after = t.mixer.inserts.clone();
        let all = infos();
        update_insert(
            &mut after,
            all[0],
            update.tone.eq.enabled,
            &[(GAINS[0], update.tone.eq.low as f32), (GAINS[1], update.tone.eq.mid as f32), (GAINS[2], update.tone.eq.high as f32)],
        )?;
        for (info, fx) in all.iter().skip(1).zip([&update.tone.effects.reverb, &update.tone.effects.delay, &update.tone.effects.chorus]) {
            update_insert(&mut after, info, fx.enabled, &[("mix", (fx.amount * 100.0) as f32)])?;
        }
        for (slot, (before, after)) in t.mixer.inserts.iter().zip(after).enumerate() {
            if before != &after {
                changes.push(Change { track: track_id, slot, before: before.clone(), after });
            }
        }
    }
    if changes.is_empty() {
        return result(e, &changes, None);
    }
    let serial = e.tone_serial.checked_add(1).ok_or_else(|| bad(APPLY, "Tone receipt sequence exhausted"))?;
    let token = format!("{}-tone-{serial:016x}", e.track_rate_epoch);
    let effect_owners = changes
        .iter()
        .filter_map(|c| {
            e.effect_owned_inserts
                .get(&(c.track, c.slot))
                .filter(|owned| Some(*owned) == c.before.as_ref())
                .map(|owned| ((c.track, c.slot), owned.clone()))
        })
        .collect();
    commit(e, APPLY, p, &changes);
    e.tone_serial = serial;
    e.tone_receipts.push_back(ToneReceipt { token: token.clone(), changes: changes.clone(), effect_owners });
    while e.tone_receipts.len() > 64 {
        e.tone_receipts.pop_front();
    }
    result(e, &changes, Some(token))
}
fn restore(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: RestoreRequest = serde_json::from_value(p.clone()).map_err(|why| bad(RESTORE, why.to_string()))?;
    if request.epoch != e.track_rate_epoch || request.receipt.len() > 128 {
        return Err(bad(RESTORE, "Epoch or receipt invalid"));
    }
    let index = e
        .tone_receipts
        .iter()
        .position(|r| r.token == request.receipt)
        .ok_or_else(|| bad(RESTORE, "Unknown, expired or consumed native tone receipt"))?;
    let receipt = e.tone_receipts.get(index).ok_or_else(|| bad(RESTORE, "Missing receipt"))?.clone();
    // Validate all changed slots, including active/preset/opaque metadata, before a single write.
    // Unrelated slots may have evolved since apply and must remain untouched.
    for change in &receipt.changes {
        let track = e.session().track(change.track).ok_or_else(|| bad(RESTORE, "Target track disappeared"))?;
        let why = reason(e, track);
        if !why.is_empty() {
            return Err(bad(RESTORE, why));
        }
        if track.mixer.inserts.get(change.slot) != Some(&change.after) {
            return Err(bad(RESTORE, "Tone insert changed since apply; undo rejected"));
        }
    }
    let changes = receipt.changes.into_iter().map(|c| Change { track: c.track, slot: c.slot, before: c.after, after: c.before }).collect::<Vec<_>>();
    commit(e, RESTORE, p, &changes);
    for (key, owner) in receipt.effect_owners {
        e.effect_owned_inserts.insert(key, owner);
    }
    e.tone_receipts.remove(index);
    result(e, &changes, None)
}
fn commit(e: &mut Engine, command: &str, p: &Value, changes: &[Change]) {
    if changes.is_empty() {
        return;
    }
    let before = e.session_arc();
    for c in changes {
        if let Some(slot) = e.session_mut().track_mut(c.track).and_then(|t| t.mixer.inserts.get_mut(c.slot)) {
            *slot = c.after.clone();
        }
        // Any former FX ownership becomes stale when a different transaction touches it.
        e.effect_owned_inserts.remove(&(c.track, c.slot));
    }
    e.push_undo(if command == APPLY { "Apply Tone Preset" } else { "Restore Tone Parameters" }, before);
    e.journal_append(command, p);
}
fn result(e: &Engine, changes: &[Change], receipt: Option<String>) -> Result<Value> {
    let mut result = snapshot(e, None);
    result["changed"] = json!(!changes.is_empty());
    result["updated"] = json!(changes.iter().map(|c| c.track).collect::<BTreeSet<_>>());
    result["receipt"] = json!(receipt);
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_model::{AutoParam, AutomationLane, ChannelFormat, Session};

    fn fixture() -> (Engine, TrackId, TrackId) {
        let mut session = Session::default();
        let a = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("A"));
        let b = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("B"));
        (Engine::new(session), a, b)
    }
    fn desired() -> Tone {
        serde_json::from_value(json!({"eq":{"enabled":true,"low":3,"mid":-2,"high":1},
        "effects":{"reverb":{"enabled":true,"amount":0.42},"delay":{"enabled":true,"amount":0.17},"chorus":{"enabled":true,"amount":0.31}}}))
        .unwrap()
    }
    fn request(e: &Engine, ids: &[TrackId], tone: &Tone) -> Value {
        json!({"epoch":e.track_rate_epoch,"updates":ids.iter().map(|id|json!({"track":id,
            "expectedInserts":view(&e.session().track(*id).unwrap().mixer.inserts),"tone":tone})).collect::<Vec<_>>()})
    }
    fn undo(e: &mut Engine, receipt: &Value) -> Result<Value> {
        e.execute(RESTORE, &json!({"epoch":e.track_rate_epoch,"receipt":receipt["receipt"]}))
    }
    fn full(e: &Engine) -> Value {
        json!(e.session())
    }

    #[test]
    fn inspect_is_read_only_and_absent_plugins_have_native_defaults() {
        let (mut e, a, _) = fixture();
        let before = e.session_arc();
        let snap = e.execute(INSPECT, &json!({"tracks":[a]})).unwrap();
        assert_eq!(snap["tracks"].as_array().unwrap().len(), 1);
        assert_eq!(snap["tracks"][0]["tone"]["eq"], json!({"enabled":false,"low":0.0,"mid":0.0,"high":0.0}));
        assert_eq!(snap["tracks"][0]["tone"]["effects"]["reverb"]["amount"], 0.25);
        assert_eq!(snap["tracks"][0]["tone"]["effects"]["delay"]["amount"], 0.3);
        assert_eq!(snap["tracks"][0]["tone"]["effects"]["chorus"]["amount"], 0.5);
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert!(!e.is_dirty());
        assert!(e.journal.is_empty());
    }
    #[test]
    fn ab_apply_and_scoped_undo_preserve_playhead_volume_rate_loop_and_other_plugins() {
        let (mut e, a, b) = fixture();
        e.transport.position = 48231;
        e.transport.playing = true;
        e.track_rates.insert(
            a,
            soundcraft_mix::TrackRateConfig {
                epoch: e.track_rate_epoch.clone(),
                track: a,
                rate: 1.25,
                revision: 8,
                loop_start: 123,
                loop_end: 48000,
            },
        );
        let mut compressor = Insert::new("compressor");
        compressor.params.insert("threshold".into(), -12.0);
        e.session_mut().track_mut(a).unwrap().mixer.inserts[9] = Some(compressor);
        e.session_mut().track_mut(a).unwrap().mixer.volume_db = -7.0;
        let rates = e.playback_rates_snapshot();
        let transport = json!(e.transport);
        let before = full(&e);
        let p = request(&e, &[a, b], &desired());
        let result = e.execute(APPLY, &p).unwrap();
        assert_eq!(result["updated"], json!([a, b]));
        assert!(result["receipt"].is_string());
        for id in [a, b] {
            let t = e.session().track(id).unwrap();
            assert_eq!(t.mixer.inserts.iter().flatten().filter(|i| infos().iter().any(|p| p.id == i.plugin)).count(), 4);
            assert_eq!(tone(t).eq.low, 3.0);
            assert!((tone(t).effects.reverb.amount - 0.42).abs() < 1e-6);
        }
        // Only inserts differ in the saved document, and neither transport nor runtime controls changed.
        let mut after = e.session().clone();
        for id in [a, b] {
            after.track_mut(id).unwrap().mixer.inserts = serde_json::from_value(
                before["tracks"].as_array().unwrap().iter().find(|t| t["id"] == json!(id)).unwrap()["mixer"]["inserts"].clone(),
            )
            .unwrap();
        }
        assert_eq!(json!(after), before);
        assert_eq!(json!(e.transport), transport);
        assert_eq!(e.playback_rates_snapshot(), rates);
        e.transport.position += 960;
        undo(&mut e, &result).unwrap();
        assert_eq!(full(&e), before);
        assert_eq!(e.transport.position, 49191);
        assert!(undo(&mut e, &result).is_err());
    }
    #[test]
    fn all_targets_preflight_before_any_write_and_capacity_failure_is_atomic() {
        let (mut e, a, b) = fixture();
        for slot in &mut e.session_mut().track_mut(b).unwrap().mixer.inserts {
            *slot = Some(Insert::new("compressor"));
        }
        let before = full(&e);
        let p = request(&e, &[a, b], &desired());
        assert!(e.execute(APPLY, &p).is_err());
        assert_eq!(full(&e), before);
        assert!(e.tone_receipts.is_empty());
        assert!(e.journal.is_empty());
    }
    #[test]
    fn cas_stale_second_track_rejects_whole_batch() {
        let (mut e, a, b) = fixture();
        let p = request(&e, &[a, b], &desired());
        e.session_mut().track_mut(b).unwrap().mixer.inserts[7] = Some(Insert::new("compressor"));
        let before = full(&e);
        assert!(e.execute(APPLY, &p).is_err());
        assert_eq!(full(&e), before);
    }
    #[test]
    fn unrelated_params_metadata_and_sparse_defaults_survive_apply_and_undo() {
        let (mut e, a, _) = fixture();
        let mut eq = Insert::new("eq_7band");
        eq.params.insert("mid_freq".into(), 1250.0);
        eq.preset = "Original EQ label".into();
        let mut fx = Insert::new("room_reverb");
        fx.params.insert("mix".into(), 25.0);
        fx.preset = "Room label".into();
        e.session_mut().track_mut(a).unwrap().mixer.inserts[2] = Some(eq.clone());
        e.session_mut().track_mut(a).unwrap().mixer.inserts[6] = Some(fx.clone());
        let p = request(&e, &[a], &desired());
        let r = e.execute(APPLY, &p).unwrap();
        let t = e.session().track(a).unwrap();
        let actual = t.mixer.inserts[2].as_ref().unwrap();
        assert_eq!(actual.params["mid_freq"], 1250.0);
        assert_eq!(actual.preset, eq.preset);
        assert_eq!(actual.params.len(), 4);
        assert_eq!(t.mixer.inserts[6].as_ref().unwrap().preset, fx.preset);
        // A plugin added to a different slot after applying is preserved by tone undo.
        let other = Insert::new("compressor");
        e.session_mut().track_mut(a).unwrap().mixer.inserts[9] = Some(other.clone());
        undo(&mut e, &r).unwrap();
        let t = e.session().track(a).unwrap();
        assert_eq!(t.mixer.inserts[2], Some(eq));
        assert_eq!(t.mixer.inserts[6], Some(fx));
        assert_eq!(t.mixer.inserts[9], Some(other));
    }
    #[test]
    fn undo_checks_full_metadata_and_never_partially_restores_ab() {
        let (mut e, a, b) = fixture();
        let p = request(&e, &[a, b], &desired());
        let r = e.execute(APPLY, &p).unwrap();
        e.session_mut().track_mut(b).unwrap().mixer.inserts[0].as_mut().unwrap().preset = "External change".into();
        let before = full(&e);
        assert!(undo(&mut e, &r).is_err());
        assert_eq!(full(&e), before);
        assert_eq!(e.tone_receipts.len(), 1);
    }
    #[test]
    fn disabled_absent_is_noop_bypassed_existing_can_update_without_enabling() {
        let (mut e, a, _) = fixture();
        let mut t = desired();
        t.eq.enabled = false;
        t.effects.reverb.enabled = false;
        t.effects.delay.enabled = false;
        t.effects.chorus.enabled = false;
        let p = request(&e, &[a], &t);
        let r = e.execute(APPLY, &p).unwrap();
        assert_eq!(r["changed"], false);
        assert!(r["receipt"].is_null());
        assert!(e.journal.is_empty());
        let mut fx = Insert::new("room_reverb");
        fx.bypass = true;
        e.session_mut().track_mut(a).unwrap().mixer.inserts[5] = Some(fx);
        let p = request(&e, &[a], &t);
        e.execute(APPLY, &p).unwrap();
        let actual = tone(e.session().track(a).unwrap());
        assert!(!actual.effects.reverb.enabled);
        assert!((actual.effects.reverb.amount - 0.42).abs() < 1e-6);
    }
    #[test]
    fn strict_validation_rejects_epoch_duplicates_bounds_recording_and_automation() {
        let (mut e, a, b) = fixture();
        let p = request(&e, &[a, b], &desired());
        let mut bad_epoch = p.clone();
        bad_epoch["epoch"] = json!("old");
        assert!(e.execute(APPLY, &bad_epoch).is_err());
        let duplicate = request(&e, &[a, a], &desired());
        assert!(e.execute(APPLY, &duplicate).is_err());
        let mut invalid = p.clone();
        invalid["updates"][0]["tone"]["eq"]["low"] = json!(24.1);
        assert!(e.execute(APPLY, &invalid).is_err());
        invalid = p.clone();
        invalid["updates"][0]["tone"]["effects"]["delay"]["amount"] = json!(-0.01);
        assert!(e.execute(APPLY, &invalid).is_err());
        e.transport.recording = true;
        assert!(e.execute(APPLY, &p).is_err());
        e.transport.recording = false;
        let mut lane = AutomationLane::new(AutoParam::Volume);
        lane.set_point(0, -4.0);
        e.session_mut().track_mut(b).unwrap().automation.push(lane);
        let p = request(&e, &[a, b], &desired());
        assert!(e.execute(APPLY, &p).is_err());
        assert!(!e.is_dirty() || e.tone_receipts.is_empty());
    }
    #[test]
    fn receipt_is_epoch_scoped_bounded_and_cannot_be_forged() {
        let (mut e, a, _) = fixture();
        for n in 0..66 {
            let mut tone = desired();
            tone.eq.low = f64::from(n % 20);
            let p = request(&e, &[a], &tone);
            e.execute(APPLY, &p).unwrap();
        }
        assert_eq!(e.tone_receipts.len(), 64);
        assert!(e.execute(RESTORE, &json!({"epoch":e.track_rate_epoch,"receipt":"forged"})).is_err());
        let receipt = e.tone_receipts.back().unwrap().token.clone();
        let old = e.track_rate_epoch.clone();
        let session = e.session().clone();
        e.replace_session(session);
        assert!(e.tone_receipts.is_empty());
        assert!(e.execute(RESTORE, &json!({"epoch":old,"receipt":receipt})).is_err());
    }
    #[test]
    fn tone_undo_restores_prior_fx_native_ownership_for_chained_undo() {
        let (mut e, a, _) = fixture();
        let p =
            json!({"epoch":e.track_rate_epoch,"effect":"reverb","updates":[{"track":a,"slot":0,"expectedInsert":null,"enabled":true,"amount":0.25}]});
        let fx = e.execute("mix.effects.set", &p).unwrap();
        assert_eq!(e.effect_owned_inserts.len(), 1);
        let p = request(&e, &[a], &desired());
        let r = e.execute(APPLY, &p).unwrap();
        undo(&mut e, &r).unwrap();
        assert_eq!(e.effect_owned_inserts.len(), 1);
        let p = json!({"epoch":e.track_rate_epoch,"effect":"reverb","updates":[{"track":a,"slot":0,"expectedInsert":fx["after"][0]["insert"],"restoreInsert":null}]});
        e.execute("mix.effects.restore", &p).unwrap();
        assert!(e.session().track(a).unwrap().mixer.inserts[0].is_none());
    }

    #[test]
    fn unsupported_tracks_and_duplicate_or_invalid_plugins_are_unavailable_without_writes() {
        for case in ["inactive", "frozen", "arm", "monitor", "mode", "pending_record", "duplicate", "inactive_insert", "opaque", "invalid_param"] {
            let (mut e, a, b) = fixture();
            match case {
                "inactive" => e.session_mut().track_mut(b).unwrap().inactive = true,
                "frozen" => e.session_mut().track_mut(b).unwrap().frozen = true,
                "arm" => e.session_mut().track_mut(b).unwrap().mixer.record_arm = true,
                "monitor" => e.session_mut().track_mut(b).unwrap().mixer.input_monitor = true,
                "mode" => e.session_mut().track_mut(b).unwrap().mixer.automation_mode = AutomationMode::Write,
                "pending_record" => e.transport_requests.push(TransportRequest::Record),
                "duplicate" => {
                    let t = e.session_mut().track_mut(b).unwrap();
                    t.mixer.inserts[0] = Some(Insert::new("chorus"));
                    t.mixer.inserts[1] = Some(Insert::new("chorus"));
                }
                "inactive_insert" => {
                    let mut i = Insert::new("eq_7band");
                    i.active = false;
                    e.session_mut().track_mut(b).unwrap().mixer.inserts[0] = Some(i);
                }
                "opaque" => {
                    let mut i = Insert::new("room_reverb");
                    i.state = Some("opaque".into());
                    e.session_mut().track_mut(b).unwrap().mixer.inserts[0] = Some(i);
                }
                "invalid_param" => {
                    let mut i = Insert::new("mod_delay");
                    i.params.insert("mix".into(), 120.0);
                    e.session_mut().track_mut(b).unwrap().mixer.inserts[0] = Some(i);
                }
                _ => {}
            }
            let inspect = e.execute(INSPECT, &json!({"tracks":[b]})).unwrap();
            assert_eq!(inspect["tracks"][0]["available"], false, "{case}");
            let read: Tone = serde_json::from_value(inspect["tracks"][0]["tone"].clone()).unwrap();
            assert!(valid(&read));
            let before = full(&e);
            let p = request(&e, &[a, b], &desired());
            assert!(e.execute(APPLY, &p).is_err(), "{case}");
            assert_eq!(full(&e), before, "{case}");
        }
    }
    #[test]
    fn repeated_identical_apply_has_no_receipt_history_or_dirty_change() {
        let (mut e, a, _) = fixture();
        let p = request(&e, &[a], &desired());
        e.execute(APPLY, &p).unwrap();
        let receipts = e.tone_receipts.len();
        let journal = e.journal.len();
        let before = e.session_arc();
        let p = request(&e, &[a], &desired());
        let r = e.execute(APPLY, &p).unwrap();
        assert_eq!(r["changed"], false);
        assert!(r["receipt"].is_null());
        assert_eq!(e.tone_receipts.len(), receipts);
        assert_eq!(e.journal.len(), journal);
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
    }
}
