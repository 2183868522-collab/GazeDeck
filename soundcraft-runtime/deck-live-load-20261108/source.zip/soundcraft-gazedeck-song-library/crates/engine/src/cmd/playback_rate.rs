//! Runtime track playback rates. These controls never edit clips or the document.
use super::{CommandSpec, always, bad};
use crate::{Engine, Result, TransportRequest, cmd};
use serde::Deserialize;
use serde_json::{Value, json};
use soundcraft_mix::TrackRateConfig;
use soundcraft_model::{ClipContent, TrackId, TrackKind};
use soundcraft_time::Samples;
use std::collections::BTreeSet;

const INSPECT: &str = "playback.rate.inspect";
const SET: &str = "playback.rate.set";
const CLEAR: &str = "playback.rate.clear";
const POLICY: &str = "fixed_seconds_independent_source_wrap";
const MAX_SAFE_INTEGER: u64 = (1_u64 << 53) - 1;

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!(query "playback.rate.inspect", "Inspect Track Playback Rates", [], None,
            "{tracks?: [id]} — runtime varispeed state, epoch, revisions, and fixed source-loop boundaries (samples)", always, inspect),
        cmd!(query "playback.rate.set", "Set Track Playback Rates", [], None,
            "{epoch, loop:{start,end}, updates:[{track,rate:0.5..2,expected:{rate,revision,loop}}]} — atomic runtime CAS; same-loop changes preserve source phase; changed boundaries require pause", always, set),
        cmd!(query "playback.rate.clear", "Clear Track Playback Rates", [], None,
            "{epoch} — paused-only removal of all runtime rates/source loops; returns native 1x without seeking or editing the document and invalidates old controls", always, clear),
    ]
}

#[derive(Clone, Copy, PartialEq, Eq, Deserialize)]
#[serde(deny_unknown_fields)]
struct LoopRange {
    start: Samples,
    end: Samples,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Expected {
    rate: f64,
    revision: u64,
    #[serde(rename = "loop")]
    source_loop: Option<LoopRange>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Update {
    track: u64,
    rate: f64,
    expected: Value,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SetRequest {
    epoch: String,
    #[serde(rename = "loop")]
    source_loop: LoopRange,
    updates: Vec<Update>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct ClearRequest {
    epoch: String,
}

pub(crate) fn track_value(e: &Engine, track: TrackId) -> Value {
    match e.track_rates.get(&track) {
        Some(config) => json!({"track":track,"rate":config.rate,"revision":config.revision,
            "loop":{"start":config.loop_start,"end":config.loop_end}}),
        None => json!({"track":track,"rate":1.0,"revision":0,"loop":null}),
    }
}

pub(crate) fn snapshot(e: &Engine, tracks: &[TrackId]) -> Value {
    json!({"version":1,"epoch":e.track_rate_epoch,"policy":POLICY,"min_rate":0.5,"max_rate":2.0,
        "tracks":tracks.iter().map(|id| track_value(e,*id)).collect::<Vec<_>>()})
}

fn inspect(e: &mut Engine, p: &Value) -> Result<Value> {
    let object = p.as_object().ok_or_else(|| bad(INSPECT, "params must be an object"))?;
    if object.keys().any(|key| key != "tracks") {
        return Err(bad(INSPECT, "only `tracks` is accepted"));
    }
    let tracks = if let Some(value) = p.get("tracks") {
        let entries = value
            .as_array()
            .filter(|items| !items.is_empty() && items.len() <= 64)
            .ok_or_else(|| bad(INSPECT, "tracks must name 1..64 unique audio track ids"))?;
        let mut ids = BTreeSet::new();
        for entry in entries {
            let id = entry
                .as_u64()
                .filter(|id| *id > 0 && *id <= MAX_SAFE_INTEGER)
                .ok_or_else(|| bad(INSPECT, "track id must be a positive safe integer"))?;
            if !ids.insert(TrackId(id)) || !e.session().track(TrackId(id)).is_some_and(|track| track.kind == TrackKind::Audio) {
                return Err(bad(INSPECT, "track does not exist, is not audio, or is duplicated"));
            }
        }
        ids.into_iter().collect::<Vec<_>>()
    } else {
        e.session().tracks.iter().filter(|track| track.kind == TrackKind::Audio).map(|track| track.id).collect()
    };
    Ok(snapshot(e, &tracks))
}

fn expected(raw: &Value) -> Result<Expected> {
    let object = raw.as_object().ok_or_else(|| bad(SET, "expected must be an object"))?;
    if object.len() != 3 || !object.contains_key("loop") {
        return Err(bad(SET, "expected needs exactly rate, revision and loop (null before first use)"));
    }
    let value: Expected = serde_json::from_value(raw.clone()).map_err(|why| bad(SET, format!("invalid expected state: {why}")))?;
    if !value.rate.is_finite() || !(0.5..=2.0).contains(&value.rate) || value.revision > MAX_SAFE_INTEGER {
        return Err(bad(SET, "invalid expected rate or revision"));
    }
    Ok(value)
}

fn set(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: SetRequest = serde_json::from_value(p.clone()).map_err(|why| bad(SET, format!("invalid request: {why}")))?;
    if request.epoch != e.track_rate_epoch {
        return Err(bad(SET, "playback session epoch changed; reopen controls"));
    }
    if e.transport.recording || e.transport_requests.iter().any(|request| matches!(request, TransportRequest::Record)) {
        return Err(bad(SET, "stop recording before changing playback rate"));
    }
    if request.updates.is_empty() || request.updates.len() > 64 {
        return Err(bad(SET, "updates must contain 1..64 unique audio tracks"));
    }
    let range = request.source_loop;
    if range.start < 0 || range.end <= range.start || range.end as u64 > MAX_SAFE_INTEGER || range.end > e.session().content_end() {
        return Err(bad(SET, "source loop must satisfy 0 <= start < end <= session content end"));
    }
    let mut seen = BTreeSet::new();
    let mut changes = Vec::with_capacity(request.updates.len());
    // Every target and precondition is checked before any runtime setting changes.
    for update in &request.updates {
        if update.track == 0
            || update.track > MAX_SAFE_INTEGER
            || !seen.insert(TrackId(update.track))
            || !update.rate.is_finite()
            || !(0.5..=2.0).contains(&update.rate)
        {
            return Err(bad(SET, "invalid or duplicated track id, or rate outside 0.5..2"));
        }
        let id = TrackId(update.track);
        let track = e
            .session()
            .track(id)
            .filter(|track| {
                track.kind == TrackKind::Audio && !track.inactive && !track.frozen && !track.mixer.input_monitor && !track.mixer.record_arm
            })
            .ok_or_else(|| bad(SET, "track must be active, unfrozen audio with input monitoring and record arm off"))?;
        let material = track.clips().iter().filter(|clip| clip.start < range.end && clip.end() > range.start);
        let mut found = false;
        for clip in material {
            let ClipContent::Audio { source, .. } = clip.content else {
                return Err(bad(SET, "source loop may contain only audio clips"));
            };
            if !e.session().pool.contains(source) {
                return Err(bad(SET, "source audio is not loaded"));
            }
            found = true;
        }
        if !found {
            return Err(bad(SET, "track has no loaded audio within the source loop"));
        }
        let expected = expected(&update.expected)?;
        let current = e.track_rates.get(&id);
        let (rate, revision, source_loop) = current
            .map(|value| (value.rate, value.revision, Some(LoopRange { start: value.loop_start, end: value.loop_end })))
            .unwrap_or((1.0, 0, None));
        if expected.rate != rate || expected.revision != revision || expected.source_loop != source_loop {
            return Err(bad(SET, "track playback rate changed; expected state did not match"));
        }
        if e.transport.playing && source_loop.is_some_and(|held| held != range) {
            return Err(bad(SET, "pause playback before changing fixed source-loop boundaries"));
        }
        if rate == update.rate && source_loop == Some(range) {
            continue;
        }
        let next_revision = revision
            .checked_add(1)
            .filter(|value| *value <= MAX_SAFE_INTEGER)
            .ok_or_else(|| bad(SET, "playback rate revision exhausted; reopen session"))?;
        changes.push(TrackRateConfig {
            track: id,
            rate: update.rate,
            revision: next_revision,
            loop_start: range.start,
            loop_end: range.end,
            epoch: e.track_rate_epoch.clone(),
        });
    }
    let changed = !changes.is_empty();
    if changed {
        for config in &changes {
            e.track_rates.insert(config.track, config.clone());
        }
        e.transport_requests.push(TransportRequest::TrackRates(changes));
    }
    let mut result = snapshot(e, &seen.into_iter().collect::<Vec<_>>());
    result["changed"] = json!(changed);
    Ok(result)
}

fn clear(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: ClearRequest = serde_json::from_value(p.clone()).map_err(|why| bad(CLEAR, format!("invalid request: {why}")))?;
    if request.epoch != e.track_rate_epoch {
        return Err(bad(CLEAR, "playback session epoch changed; reopen controls"));
    }
    let starting = e.transport_requests.iter().any(|request| {
        matches!(
            request,
            TransportRequest::Play
                | TransportRequest::PlayFrom(_)
                | TransportRequest::TogglePlay
                | TransportRequest::PlaySelection
                | TransportRequest::Record
                | TransportRequest::HalfSpeed
                | TransportRequest::DeckPlayback { start: true, .. }
                | TransportRequest::Scrub(_)
        )
    });
    if e.transport.recording || e.transport.playing || starting {
        return Err(bad(CLEAR, "pause playback and stop recording before clearing runtime rates"));
    }
    e.track_rates.clear();
    // Rotate even when already native: any earlier popup must cease being an
    // authority to re-enable a material loop after this explicit cancellation.
    e.track_rate_epoch = format!("{:016x}", crate::new_scheme_id(e.session()));
    e.transport_requests.push(TransportRequest::ClearTrackRates(e.track_rate_epoch.clone()));
    let mut result = e.playback_rates_snapshot();
    result["changed"] = json!(true);
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_model::{ChannelFormat, Clip, Session, TrackKind};

    fn fixture() -> (Engine, TrackId, TrackId) {
        let mut session = Session::default();
        let mut ids = Vec::new();
        for name in ["A", "B"] {
            let id = session.add_track(TrackKind::Audio, ChannelFormat::Mono, Some(name));
            let source = crate::io::add_source(
                &mut session,
                name,
                soundcraft_audio_io::AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.25; 4800]] },
                None,
                soundcraft_audio_io::FileFormat::Wav,
            );
            let clip = session.new_clip_id();
            crate::edit::place_clip(&mut session, id, Clip::audio(clip, name, source, 0, 0, 4800));
            ids.push(id);
        }
        (Engine::new(session), ids[0], ids[1])
    }

    fn request(e: &Engine, updates: &[(TrackId, f64)]) -> Value {
        json!({"epoch":e.track_rate_epoch,"loop":{"start":0,"end":4800},"updates":updates.iter().map(|(id,rate)| {
            let mut expected = track_value(e,*id); expected.as_object_mut().unwrap().remove("track");
            json!({"track":id,"rate":rate,"expected":expected})
        }).collect::<Vec<_>>()})
    }

    #[test]
    fn atomic_runtime_rates_do_not_edit_the_document_transport_or_global_history() {
        let (mut e, a, b) = fixture();
        let before = e.session_arc();
        let revision = e.revision;
        let position = e.transport.position;
        let params = request(&e, &[(a, 1.25), (b, 0.75)]);
        let result = e.execute(SET, &params).unwrap();
        assert_eq!(result["changed"], true);
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert!(!e.is_dirty());
        assert!(!e.can_undo());
        assert_eq!(e.revision, revision);
        assert_eq!(e.transport.position, position);
        assert!(matches!(e.transport_requests.as_slice(),[TransportRequest::TrackRates(batch)] if batch.len()==2));
        assert_eq!(track_value(&e, a)["rate"], 1.25);
        assert_eq!(track_value(&e, b)["rate"], 0.75);
        assert_eq!(e.journal.len(), 0);
    }

    #[test]
    fn stale_second_deck_rejects_the_whole_batch_and_keeps_first_deck_untouched() {
        let (mut e, a, b) = fixture();
        let mut params = request(&e, &[(a, 1.25), (b, 0.75)]);
        params["updates"][1]["expected"]["revision"] = json!(9);
        assert!(e.execute(SET, &params).is_err());
        assert!(e.track_rates.is_empty());
        assert!(e.transport_requests.is_empty());
    }

    #[test]
    fn unchanged_values_are_read_only_and_numeric_expected_values_are_canonical() {
        let (mut e, a, _) = fixture();
        let mut params = request(&e, &[(a, 1.0)]);
        params["updates"][0]["expected"]["rate"] = json!(1);
        e.execute(SET, &params).unwrap();
        e.transport_requests.clear();
        let params = request(&e, &[(a, 1.0)]);
        let result = e.execute(SET, &params).unwrap();
        assert_eq!(result["changed"], false);
        assert!(e.transport_requests.is_empty());
        assert_eq!(track_value(&e, a)["revision"], 1);
    }

    #[test]
    fn parameter_undo_restores_only_rate_and_does_not_restore_elapsed_time() {
        let (mut e, a, _) = fixture();
        let params = request(&e, &[(a, 1.2)]);
        e.execute(SET, &params).unwrap();
        e.transport.position = 1999;
        e.transport.playing = true;
        let params = request(&e, &[(a, 1.0)]);
        e.execute(SET, &params).unwrap();
        assert_eq!(track_value(&e, a)["rate"], 1.0);
        assert_eq!(e.transport.position, 1999);
        assert!(e.transport.playing);
    }

    #[test]
    fn reopen_same_document_changes_epoch_and_resets_all_runtime_rates() {
        let (mut e, a, _) = fixture();
        let params = request(&e, &[(a, 1.2)]);
        e.execute(SET, &params).unwrap();
        let epoch = e.track_rate_epoch.clone();
        e.replace_session(e.session().clone());
        assert_ne!(e.track_rate_epoch, epoch);
        assert_eq!(track_value(&e, a)["rate"], 1.0);
        assert_eq!(track_value(&e, a)["revision"], 0);
        assert!(e.execute(SET, &params).is_err());
    }

    #[test]
    fn recording_bad_targets_unknown_fields_and_loop_bounds_never_mutate() {
        for change in ["recording", "pending_record", "rate", "duplicate", "missing_expected_loop", "unknown", "end", "kind", "inactive", "unloaded"]
        {
            let (mut e, a, b) = fixture();
            let mut params = request(&e, &[(a, 1.2)]);
            match change {
                "recording" => e.transport.recording = true,
                "pending_record" => e.transport_requests.push(TransportRequest::Record),
                "rate" => params["updates"][0]["rate"] = json!(2.01),
                "duplicate" => params["updates"] = json!([params["updates"][0], params["updates"][0]]),
                "missing_expected_loop" => {
                    params["updates"][0]["expected"].as_object_mut().unwrap().remove("loop");
                }
                "unknown" => params["unknown"] = json!(1),
                "end" => params["loop"]["end"] = json!(4801),
                "kind" => e.session_mut().track_mut(a).unwrap().kind = TrackKind::Midi,
                "inactive" => e.session_mut().track_mut(a).unwrap().inactive = true,
                "unloaded" => {
                    let src = e.session().track(a).unwrap().clips()[0].source().unwrap();
                    e.session_mut().pool.remove(src);
                }
                _ => {}
            }
            assert!(e.execute(SET, &params).is_err(), "{change}");
            assert!(e.track_rates.is_empty(), "{change}");
            assert_eq!(track_value(&e, b)["rate"], 1.0);
        }
    }

    #[test]
    fn loop_reconfiguration_requires_pause_but_mouse_selection_does_not_change_fixed_loop() {
        let (mut e, a, _) = fixture();
        let params = request(&e, &[(a, 1.2)]);
        e.execute(SET, &params).unwrap();
        e.transport.playing = true;
        e.session_mut().edit.selection = soundcraft_time::Range::point(400);
        let params = request(&e, &[(a, 1.3)]);
        assert!(e.execute(SET, &params).is_ok());
        let mut params = request(&e, &[(a, 1.3)]);
        params["loop"]["end"] = json!(4000);
        assert!(e.execute(SET, &params).is_err());
        e.transport.playing = false;
        assert!(e.execute(SET, &params).is_ok());
    }

    #[test]
    fn clear_runtime_rates_resets_both_decks_and_epoch_without_seeking_or_editing() {
        let (mut e, a, b) = fixture();
        let stale_set = request(&e, &[(a, 1.2), (b, 0.8)]);
        e.execute(SET, &stale_set).unwrap();
        e.transport_requests.clear();
        e.transport.position = 2111;
        let before = e.session_arc();
        let revision = e.revision;
        let epoch = e.track_rate_epoch.clone();
        let result = e.execute(CLEAR, &json!({"epoch":epoch})).unwrap();
        assert_eq!(result["changed"], true);
        assert_ne!(e.track_rate_epoch, epoch);
        assert_eq!(result["epoch"], e.track_rate_epoch);
        assert!(e.track_rates.is_empty());
        for id in [a, b] {
            assert_eq!(track_value(&e, id), json!({"track":id,"rate":1.0,"revision":0,"loop":null}));
        }
        assert_eq!(e.transport_requests, [TransportRequest::ClearTrackRates(e.track_rate_epoch.clone())]);
        assert_eq!(e.transport.position, 2111);
        assert!(!e.transport.playing);
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert_eq!(e.revision, revision);
        assert!(!e.is_dirty());
        assert!(!e.can_undo());
        assert_eq!(e.journal.len(), 0);
        assert!(e.execute(SET, &stale_set).is_err());
    }

    #[test]
    fn clear_refuses_stale_playing_recording_and_unknown_fields_without_side_effects() {
        for change in ["stale", "playing", "recording", "pending_play", "unknown"] {
            let (mut e, a, _) = fixture();
            let params = request(&e, &[(a, 1.2)]);
            e.execute(SET, &params).unwrap();
            e.transport_requests.clear();
            let epoch = e.track_rate_epoch.clone();
            let before = e.track_rates.clone();
            let mut params = json!({"epoch":epoch});
            match change {
                "stale" => params["epoch"] = json!("old-session"),
                "playing" => e.transport.playing = true,
                "recording" => e.transport.recording = true,
                "pending_play" => e.transport_requests.push(TransportRequest::Play),
                "unknown" => params["all"] = json!(true),
                _ => {}
            }
            let requests = e.transport_requests.clone();
            assert!(e.execute(CLEAR, &params).is_err(), "{change}");
            assert_eq!(e.track_rates, before, "{change}");
            assert_eq!(e.track_rate_epoch, epoch, "{change}");
            assert_eq!(e.transport_requests, requests, "{change}");
        }
    }
}
