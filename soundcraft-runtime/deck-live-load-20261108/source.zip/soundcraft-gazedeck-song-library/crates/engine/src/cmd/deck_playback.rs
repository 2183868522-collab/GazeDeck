//! Deck transport and loading songs into separate native playlists.
use super::{CommandSpec, always, bad};
use crate::{Engine, Result, TransportRequest, cmd};
use serde::Deserialize;
use serde_json::{Value, json};
use soundcraft_model::{Clip, Playlist, TrackId, TrackKind};
use std::collections::BTreeSet;
use std::path::Path;

const INSPECT: &str = "playback.deck.inspect";
const SET: &str = "playback.deck.set";
const SEEK: &str = "playback.deck.seek";
const LOAD: &str = "playback.deck.load";
const SONG_PLAYLIST_PREFIX: &str = "GazeDeck · ";
const MAX_SAFE_INTEGER: u64 = (1_u64 << 53) - 1;

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!(query "playback.deck.inspect", "Inspect Deck Playback", [], None,
            "{tracks?: [id]} — project transport and audio-track pause state", always, inspect),
        cmd!(query "playback.deck.set", "Set Deck Playback", [], None,
            "{epoch,track,paused,expected_paused,expected_playing,peer?:id} — scoped runtime transport", always, set),
        cmd!(query "playback.deck.seek", "Seek Deck", [], None,
            "{epoch,track,offset_samples} — move one runtime material cursor by up to 30 seconds", always, seek),
        cmd!("playback.deck.load", "Load Deck Song", [], None,
            "{epoch,track,path,name} — choose a song playlist and cue at the start with the current play state", always, load),
    ]
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct InspectRequest {
    tracks: Option<Vec<u64>>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SetRequest {
    epoch: String,
    track: u64,
    paused: bool,
    expected_paused: bool,
    expected_playing: bool,
    peer: Option<u64>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SeekRequest {
    epoch: String,
    track: u64,
    offset_samples: i64,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LoadRequest {
    epoch: String,
    track: u64,
    path: String,
    name: String,
}

fn track_id(e: &Engine, command: &str, id: u64) -> Result<TrackId> {
    let track = TrackId(id);
    if id > 0 && id <= MAX_SAFE_INTEGER && e.session().track(track).is_some_and(|t| t.kind == TrackKind::Audio) {
        Ok(track)
    } else {
        Err(bad(command, "expected a valid audio track id"))
    }
}

fn snapshot(e: &Engine, tracks: &[TrackId], playing: bool) -> Value {
    let rows = tracks.iter().map(|&track| {
        let desired = e.deck_paused.get(&track).copied();
        let paused = desired.unwrap_or(false);
        let position = if let Some(paused) = desired {
            e.deck_audio.iter().find(|state| state.track == track && state.paused == paused).map(|state| state.position)
        } else {
            Some(e.transport.position)
        };
        json!({"track": track, "paused": paused, "position": position})
    }).collect::<Vec<_>>();
    let mut value = json!({
        "version": 1, "epoch": e.track_rate_epoch, "playing": playing, "tracks": rows,
        "seek_supported": true, "load_supported": true,
    });
    if let Some(seek) = e.deck_seek_receipt {
        value["last_seek"] = json!(seek);
    }
    value
}

fn audio_tracks(e: &Engine) -> Vec<TrackId> {
    e.session().tracks.iter().filter(|track| track.kind == TrackKind::Audio).map(|track| track.id).collect()
}

fn inspect(e: &mut Engine, params: &Value) -> Result<Value> {
    let request: InspectRequest = serde_json::from_value(params.clone()).map_err(|error| bad(INSPECT, error.to_string()))?;
    let tracks = if let Some(ids) = request.tracks {
        if ids.is_empty() || ids.len() > 64 {
            return Err(bad(INSPECT, "tracks must contain 1..64 unique audio track ids"));
        }
        let mut tracks = BTreeSet::new();
        for id in ids {
            if !tracks.insert(track_id(e, INSPECT, id)?) {
                return Err(bad(INSPECT, "duplicate audio track id"));
            }
        }
        tracks.into_iter().collect()
    } else {
        audio_tracks(e)
    };
    Ok(snapshot(e, &tracks, e.transport.playing))
}

fn set(e: &mut Engine, params: &Value) -> Result<Value> {
    let request: SetRequest = serde_json::from_value(params.clone()).map_err(|error| bad(SET, error.to_string()))?;
    if request.epoch != e.track_rate_epoch {
        return Err(bad(SET, "playback session epoch changed; reopen controls"));
    }
    let track = track_id(e, SET, request.track)?;
    let peer = request.peer.map(|id| track_id(e, SET, id)).transpose()?;
    if peer == Some(track) {
        return Err(bad(SET, "peer must identify a different audio track"));
    }
    let playing = e.transport.playing;
    if playing != request.expected_playing || e.deck_paused.get(&track).copied().unwrap_or(false) != request.expected_paused {
        return Err(bad(SET, "transport or deck state changed; refresh controls"));
    }
    if e.transport.recording || e.transport_requests.iter().any(|request| {
        matches!(request, TransportRequest::ResetSession | TransportRequest::Play | TransportRequest::PlayFrom(_)
            | TransportRequest::Pause | TransportRequest::Stop | TransportRequest::Record | TransportRequest::TogglePlay
            | TransportRequest::PlaySelection | TransportRequest::HalfSpeed | TransportRequest::DeckPlayback { start: true, .. })
    }) {
        return Err(bad(SET, "wait for pending transport changes and stop recording before controlling a deck"));
    }
    let start = !playing && !request.paused;
    if [Some(track), peer.filter(|_| start)].into_iter().flatten().any(|id| {
        e.session().track(id).is_some_and(|t| t.inactive || t.mixer.input_monitor || t.mixer.record_arm)
    }) {
        return Err(bad(SET, "deck playback requires active, non-monitored, unarmed audio tracks"));
    }
    let mut updates = vec![(track, request.paused)];
    if start && let Some(peer) = peer {
        updates.push((peer, true));
    }
    for &(id, paused) in &updates {
        e.deck_paused.insert(id, paused);
    }
    e.transport_requests.push(TransportRequest::DeckPlayback { updates, start, epoch: request.epoch });
    Ok(snapshot(e, &audio_tracks(e), playing || start))
}

fn seek(e: &mut Engine, params: &Value) -> Result<Value> {
    let request: SeekRequest = serde_json::from_value(params.clone()).map_err(|error| bad(SEEK, error.to_string()))?;
    if request.epoch != e.track_rate_epoch {
        return Err(bad(SEEK, "playback session epoch changed; reopen controls"));
    }
    let track = track_id(e, SEEK, request.track)?;
    let limit = u64::from(e.session().sample_rate.hz()) * 30;
    if request.offset_samples == 0 || request.offset_samples.unsigned_abs() > limit {
        return Err(bad(SEEK, "offset_samples must be nonzero and within 30 seconds"));
    }
    if e.transport.recording || e.transport_requests.iter().any(|request| {
        matches!(request, TransportRequest::ResetSession | TransportRequest::Play | TransportRequest::PlayFrom(_)
            | TransportRequest::Pause | TransportRequest::Stop | TransportRequest::Record | TransportRequest::TogglePlay
            | TransportRequest::Locate(_) | TransportRequest::Scrub(_) | TransportRequest::PlaySelection | TransportRequest::HalfSpeed
            | TransportRequest::DeckPlayback { .. } | TransportRequest::DeckSeek { .. } | TransportRequest::ClearTrackRates(_))
    }) {
        return Err(bad(SEEK, "wait for pending transport changes and stop recording before seeking a deck"));
    }
    let lane = e.session().track(track).ok_or_else(|| bad(SEEK, "audio track changed"))?;
    if lane.inactive || lane.mixer.input_monitor || lane.mixer.record_arm {
        return Err(bad(SEEK, "deck seek requires an active, non-monitored, unarmed audio track"));
    }
    let last_sample = lane.clips().iter().filter(|clip| clip.is_audio()).map(|clip| clip.range().end).max()
        .filter(|&end| end > 0 && end as u64 <= MAX_SAFE_INTEGER)
        .ok_or_else(|| bad(SEEK, "deck has no seekable audio clips"))? - 1;
    let revision = e.deck_seek_serial.checked_add(1).filter(|&id| id <= MAX_SAFE_INTEGER)
        .ok_or_else(|| bad(SEEK, "deck seek revision exhausted; reopen session"))?;
    e.deck_seek_serial = revision;
    e.deck_paused.entry(track).or_insert(false);
    e.transport_requests.push(TransportRequest::DeckSeek {
        track, offset: request.offset_samples, last_sample, revision, epoch: request.epoch,
    });
    Ok(json!({"epoch": e.track_rate_epoch, "track": track, "revision": revision}))
}

fn load(e: &mut Engine, params: &Value) -> Result<Value> {
    let request: LoadRequest = serde_json::from_value(params.clone()).map_err(|error| bad(LOAD, error.to_string()))?;
    if request.epoch != e.track_rate_epoch {
        return Err(bad(LOAD, "playback session epoch changed; reopen controls"));
    }
    if e.transport.recording || !e.transport_requests.is_empty() {
        return Err(bad(LOAD, "stop recording and wait for transport changes before loading a song"));
    }
    if !e.track_rates.is_empty() {
        return Err(bad(LOAD, "clear configured Deck varispeed loops before loading a song"));
    }
    let track = track_id(e, LOAD, request.track)?;
    // Keep the target's playback intent. A running Deck starts the new song
    // immediately; a parked Deck remains parked. The peer is untouched.
    let paused = !e.transport.playing || e.deck_paused.get(&track).copied().unwrap_or(false);
    let lane = e.session().track(track).ok_or_else(|| bad(LOAD, "audio track changed"))?;
    if lane.inactive || lane.frozen || lane.mixer.input_monitor || lane.mixer.record_arm {
        return Err(bad(LOAD, "song loading requires an active, unfrozen, non-monitored, unarmed audio track"));
    }
    let path = Path::new(&request.path);
    if request.path.len() > 8192 || !path.is_absolute() || !crate::io::file_found(path) {
        return Err(bad(LOAD, "song file is unavailable"));
    }
    if request.name.chars().count() > 256 || request.name.chars().any(|c| c.is_control() || matches!(c, '/' | '\\' | ':')) {
        return Err(bad(LOAD, "expected a display filename without a path"));
    }
    let title = Path::new(&request.name).file_stem().and_then(std::ffi::OsStr::to_str).filter(|s| !s.trim().is_empty())
        .ok_or_else(|| bad(LOAD, "expected a song title"))?;
    let rate = e.session().sample_rate.hz();
    let result = if let Some((index, clip, source, frames, channels)) = lane.playlists.iter().enumerate().find_map(|(index, pl)| {
        let [clip] = pl.clips.as_slice() else { return None };
        let source = e.session().sources.iter().find(|source| {
            source.path == request.path && source.name == title && source.sample_rate == rate
                && clip.source() == Some(source.id) && e.session().pool.contains(source.id)
        })?;
        let frames = i64::try_from(source.frames).ok()?;
        // A native edit to a previously loaded clip turns it into a separate
        // arrangement. Keep it and prepare a fresh song playlist instead.
        (pl.name.starts_with(SONG_PLAYLIST_PREFIX)
            && clip == &Clip::audio(clip.id, title.to_string(), source.id, 0, 0, frames))
            .then_some((index, clip.id, source.id, frames, source.channels))
    }) {
        let lane = e.session_mut().track_mut(track).ok_or_else(|| bad(LOAD, "audio track changed"))?;
        lane.active_playlist = index;
        json!({"track": track, "clip": clip, "source": source, "frames": frames, "channels": channels})
    } else {
        let decoded = crate::io::decode_deck_import(path, rate)?;
        let lane = e.session_mut().track_mut(track).ok_or_else(|| bad(LOAD, "audio track changed"))?;
        let base = format!("{SONG_PLAYLIST_PREFIX}{title}");
        let name = if lane.playlists.iter().any(|pl| pl.name == base) {
            (2..=lane.playlists.len().saturating_add(1)).map(|i| format!("{base} ({i})"))
                .find(|name| !lane.playlists.iter().any(|pl| pl.name == *name))
                .ok_or_else(|| bad(LOAD, "no free song playlist name"))?
        } else {
            base
        };
        lane.active_playlist = lane.playlists.len();
        lane.playlists.push(Playlist::new(name));
        crate::io::place_decoded(e, &request.name, decoded, Some(&request.path), Some(track), 0)?
    };
    e.deck_paused.insert(track, paused);
    e.deck_audio.retain(|state| state.track != track);
    if e.deck_seek_receipt.is_some_and(|seek| seek.track == track) {
        e.deck_seek_receipt = None;
    }
    e.transport_requests.push(TransportRequest::DeckCue { track, paused, epoch: request.epoch });
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_audio_io::{AudioBuffer, EncodeOptions, FileFormat};
    use soundcraft_model::{ChannelFormat, Session};

    #[test]
    fn deck_start_pauses_only_peer_and_pause_never_stops_project() {
        let mut session = Session::default();
        let a = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("A"));
        let b = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("B"));
        let mut engine = Engine::new(session);
        let epoch = engine.track_rate_epoch.clone();
        let initial = engine.execute(INSPECT, &json!({})).unwrap();
        assert_eq!(initial["playing"], false);
        let start = json!({"epoch":epoch,"track":a,"paused":false,"expected_paused":false,"expected_playing":false,"peer":b});
        let result = engine.execute(SET, &start).unwrap();
        assert_eq!(result["playing"], true);
        assert_eq!(result["tracks"][1]["paused"], true);
        assert!(matches!(engine.transport_requests.pop(), Some(TransportRequest::DeckPlayback { updates, start:true, .. })
            if updates == vec![(a, false),(b, true)]));
        engine.transport.playing = true;
        let before = engine.session_arc();
        let pause = json!({"epoch":epoch,"track":a,"paused":true,"expected_paused":false,"expected_playing":true});
        assert_eq!(engine.execute(SET, &pause).unwrap()["playing"], true);
        assert!(matches!(engine.transport_requests.last(), Some(TransportRequest::DeckPlayback { updates, start:false, .. })
            if updates == &vec![(a, true)]));
        assert!(engine.execute(SET, &pause).is_err());
        assert!(std::sync::Arc::ptr_eq(&before, &engine.session_arc()));
    }

    #[test]
    fn deck_load_preserves_the_old_playlist_peer_and_undo() {
        let dir = std::env::temp_dir().join(format!("sc-deck-song-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("fixture.wav");
        let mut session = Session::default();
        let a = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("A"));
        let b = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("B"));
        let sample_rate = session.sample_rate.hz();
        let buffer = AudioBuffer { sample_rate, channels: vec![vec![0.25; 480]] };
        let bytes = soundcraft_audio_io::encode(&buffer, &EncodeOptions::default()).unwrap();
        std::fs::write(&path, b"invalid audio").unwrap();
        let source = crate::io::add_source(&mut session, "Old arrangement", buffer, None, FileFormat::Wav);
        for id in [a, b] {
            let clip = session.new_clip_id();
            crate::edit::place_clip(&mut session, id, Clip::audio(clip, "Old arrangement", source, 0, 0, 480));
        }
        session.track_mut(a).unwrap().mixer.volume_db = -9.0;
        let original_a = session.track(a).unwrap().clone();
        let original_b = session.track(b).unwrap().clone();
        let mut engine = Engine::new(session);
        engine.transport.position = 123;
        let request = json!({"epoch":engine.track_rate_epoch,"track":a,"path":path,"name":"海浪.wav"});
        let before = engine.session_arc();
        assert!(engine.execute(LOAD, &request).is_err());
        assert!(std::sync::Arc::ptr_eq(&before, &engine.session_arc()));
        std::fs::write(&path, bytes).unwrap();
        engine.transport.playing = true;
        let loaded = engine.execute(LOAD, &request).unwrap();
        assert_eq!(loaded["frames"], 480);
        assert_eq!(engine.session().track(a).unwrap().clips()[0].name, "海浪");
        assert_eq!(engine.session().track(a).unwrap().playlists[0], original_a.playlists[0]);
        assert_eq!(engine.session().track(a).unwrap().mixer, original_a.mixer);
        assert_eq!(engine.session().track(b), Some(&original_b));
        assert!(engine.transport.playing);
        assert_eq!(engine.deck_paused.get(&a), Some(&false));
        assert_eq!(engine.deck_paused.get(&b), None);
        assert_eq!(engine.transport.position, 123);
        assert!(matches!(engine.transport_requests.pop(), Some(TransportRequest::DeckCue { track, paused: false, .. }) if track == a));
        let source_count = engine.session().sources.len();
        engine.deck_paused.insert(a, true);
        assert_eq!(engine.execute(LOAD, &request).unwrap(), loaded);
        assert!(matches!(engine.transport_requests.pop(), Some(TransportRequest::DeckCue { track, paused: true, .. }) if track == a));
        assert_eq!(engine.session().sources.len(), source_count);
        assert_eq!(engine.session().track(a).unwrap().playlists.len(), 2);
        assert!(engine.undo());
        assert!(engine.undo());
        assert_eq!(engine.session().track(a), Some(&original_a));
        std::fs::remove_file(&path).unwrap();
        std::fs::remove_dir(&dir).unwrap();
    }
}
