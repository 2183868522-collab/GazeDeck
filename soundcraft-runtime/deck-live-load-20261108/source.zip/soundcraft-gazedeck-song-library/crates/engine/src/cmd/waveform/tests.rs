use super::*;
use soundcraft_audio_io::{AudioBuffer, FileFormat};
use soundcraft_model::{ChannelFormat, Clip, SourceAudio, SourceId};
use soundcraft_time::Range;
use std::sync::Arc;

fn add_audio(session: &mut Session, name: &str, channels: Vec<Vec<f32>>, start: i64, length: i64) -> TrackId {
    let source = crate::io::add_source(session, name, AudioBuffer { sample_rate: 48_000, channels }, None, FileFormat::Wav);
    let track = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some(name));
    let id = session.new_clip_id();
    session.track_mut(track).unwrap().playlist_mut().unwrap().clips.push(Clip::audio(id, name, source, 0, start, length));
    track
}
fn fixture() -> (Engine, TrackId) {
    let mut session = Session::default();
    let track = add_audio(&mut session, "Real clip", vec![vec![0.25; 128], vec![-0.6; 128]], 0, 128);
    (Engine::new(session), track)
}
fn query(engine: &mut Engine, tracks: &[TrackId]) -> Value {
    engine.execute(INSPECT, &json!({"tracks":tracks.iter().map(|t|t.0).collect::<Vec<_>>(),"bins":32})).unwrap()
}
fn row(value: &Value) -> &Value {
    &value["tracks"][0]
}
fn unsupported(value: &Value) {
    assert_eq!(row(value)["available"], false);
    assert!(row(value)["reason"].as_str().is_some_and(|reason| !reason.is_empty()));
    assert!(row(value)["peaks"].as_array().unwrap().iter().all(Value::is_null));
}

#[test]
fn exposes_loaded_stereo_envelope_and_clip_metadata_in_requested_order() {
    let (mut e, a) = fixture();
    let b = add_audio(e.session_mut(), "Second", vec![vec![0.8; 128]], 0, 128);
    let epoch = e.track_rate_epoch.clone();
    let result = query(&mut e, &[b, a]);
    assert_eq!(result["version"], 1);
    assert_eq!(result["epoch"], epoch);
    assert_eq!(result["kind"], "source_envelope_pre_fader");
    assert_eq!((result["sampleRate"].as_u64(), result["lengthSamples"].as_i64()), (Some(48_000), Some(128)));
    assert_eq!(result["tracks"][0]["track"], b.0);
    assert_eq!(result["tracks"][1]["track"], a.0);
    let r = &result["tracks"][1];
    assert_eq!(r["available"], true);
    assert_eq!(r["reason"], "");
    assert_eq!(r["peaks"].as_array().unwrap().len(), 32);
    assert_eq!(r["clips"][0]["name"], "Real clip");
    assert_eq!(r["clips"][0]["offset"], 0);
    assert_eq!(r["clips"][0]["stretch"], 1.0);
    let first = r["peaks"][0].as_array().unwrap();
    assert!((first[0].as_f64().unwrap() + 0.6).abs() < 1e-6);
    assert!((first[1].as_f64().unwrap() - 0.25).abs() < 1e-6);
}

#[test]
fn gaps_are_null_and_digital_silence_is_a_zero_span() {
    let mut session = Session::default();
    let t = add_audio(&mut session, "Silence", vec![vec![0.0; 32]], 32, 32);
    let result = query(&mut Engine::new(session), &[t]);
    let peaks = row(&result)["peaks"].as_array().unwrap();
    assert!(peaks[..16].iter().all(Value::is_null));
    assert!(peaks[16..].iter().all(|span| *span == json!([0.0, 0.0])));
}

#[test]
fn source_offset_and_stretch_place_the_real_pulse_on_the_correct_timeline() {
    let mut session = Session::default();
    let mut signal = vec![0.0; 128];
    signal[40] = 0.9;
    let t = add_audio(&mut session, "Trimmed stretched", vec![signal], 32, 64);
    {
        let clip = &mut session.track_mut(t).unwrap().playlist_mut().unwrap().clips[0];
        clip.content = ClipContent::Audio { source: clip.source().unwrap(), offset: 16 };
        clip.stretch = 2.0;
    }
    let result = query(&mut Engine::new(session), &[t]);
    // Three timeline samples per bin: the impulse at source40 is at timeline80.
    let peaks = row(&result)["peaks"].as_array().unwrap();
    assert!(peaks[..10].iter().all(Value::is_null));
    assert_eq!(peaks[15], json!([0.0, 0.0]));
    assert!(peaks[26][1].as_f64().unwrap() > 0.89);
    assert_eq!(peaks[29], json!([0.0, 0.0]));
}

#[test]
fn overlapping_clips_are_unioned_not_added_and_controls_do_not_scale_the_source() {
    let (mut e, t) = fixture();
    let second = add_audio(e.session_mut(), "Overlapping", vec![vec![0.7; 128]], 0, 128);
    let clip = e.session().track(second).unwrap().clips()[0].clone();
    let target = e.session_mut().track_mut(t).unwrap();
    target.playlist_mut().unwrap().clips.push(clip);
    target.mixer.volume_db = -80.0;
    for clip in &mut target.playlist_mut().unwrap().clips {
        clip.gain_db = -40.0;
        clip.muted = true;
        clip.fade_in.len = 64;
    }
    let result = query(&mut e, &[t]);
    let first = &row(&result)["peaks"][0];
    assert!((first[0].as_f64().unwrap() + 0.6).abs() < 1e-6);
    assert!((first[1].as_f64().unwrap() - 0.7).abs() < 1e-6);
    assert!(row(&result)["clips"].as_array().unwrap().iter().all(|clip| clip["muted"] == true));
}

#[test]
fn negative_clip_start_and_source_offset_preserve_real_silence_bounds() {
    let mut session = Session::default();
    let t = add_audio(&mut session, "Negative", vec![vec![0.5; 64]], -16, 80);
    let clip = &mut session.track_mut(t).unwrap().playlist_mut().unwrap().clips[0];
    clip.content = ClipContent::Audio { source: clip.source().unwrap(), offset: -32 };
    let result = query(&mut Engine::new(session), &[t]);
    assert_eq!(row(&result)["clips"][0]["start"], -16);
    assert_eq!(row(&result)["clips"][0]["offset"], -32);
    assert_eq!(row(&result)["peaks"][0], json!([0.0, 0.0]));
    assert_eq!(row(&result)["peaks"][7], json!([0.0, 0.0]), "exclusive source start must not leak a sample into the preceding silent bin");
    assert!(row(&result)["peaks"][20][1].as_f64().unwrap() > 0.49);
}

#[test]
fn absent_source_never_returns_a_fabricated_partial_waveform() {
    let (mut e, t) = fixture();
    let source = e.session().track(t).unwrap().clips()[0].source().unwrap();
    e.session_mut().pool.remove(source);
    let result = query(&mut e, &[t]);
    unsupported(&result);
    assert_eq!(row(&result)["clips"].as_array().unwrap().len(), 1);
    assert!(row(&result)["reason"].as_str().unwrap().contains("not loaded"));
}

#[test]
fn sample_rate_mismatch_and_inconsistent_overview_are_explicitly_unavailable() {
    let (mut e, t) = fixture();
    let source = e.session().track(t).unwrap().clips()[0].source().unwrap();
    e.session_mut().pool.insert(source, Arc::new(SourceAudio::new(AudioBuffer { sample_rate: 44_100, channels: vec![vec![0.5; 128]] })));
    unsupported(&query(&mut e, &[t]));
    let mut audio = SourceAudio::new(AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.5; 128]] });
    audio.buffer.channels[0].push(0.4);
    e.session_mut().pool.insert(source, Arc::new(audio));
    unsupported(&query(&mut e, &[t]));
}

#[test]
fn non_finite_peaks_are_unavailable_but_finite_float_headroom_is_retained() {
    let (mut e, t) = fixture();
    let source = e.session().track(t).unwrap().clips()[0].source().unwrap();
    e.session_mut().pool.insert(source, Arc::new(SourceAudio::new(AudioBuffer { sample_rate: 48_000, channels: vec![vec![f32::INFINITY; 128]] })));
    unsupported(&query(&mut e, &[t]));
    e.session_mut().pool.insert(source, Arc::new(SourceAudio::new(AudioBuffer { sample_rate: 48_000, channels: vec![vec![2.0; 128]] })));
    let result = query(&mut e, &[t]);
    assert_eq!(row(&result)["available"], true);
    assert_eq!(row(&result)["peaks"][0], json!([2.0, 2.0]));
}

#[test]
fn hostile_or_ambiguous_requests_fail_without_state_changes() {
    let (mut e, t) = fixture();
    let before = crate::inspect::session(&e, true);
    for params in [
        json!({}),
        json!({"tracks":[]}),
        json!({"tracks":[t.0,t.0]}),
        json!({"tracks":[0]}),
        json!({"tracks":[MAX_SAFE+1]}),
        json!({"tracks":[t.0],"bins":31}),
        json!({"tracks":[t.0],"bins":1025}),
        json!({"tracks":[t.0],"bins":64.5}),
        json!({"tracks":[t.0],"path":"arbitrary.wav"}),
    ] {
        assert!(e.execute(INSPECT, &params).is_err(), "{params}");
        assert_eq!(crate::inspect::session(&e, true), before);
    }
    let midi = e.session_mut().add_track(TrackKind::Midi, ChannelFormat::Mono, Some("MIDI"));
    assert!(e.execute(INSPECT, &json!({"tracks":[midi.0]})).is_err());
}

#[test]
fn empty_track_and_over_budget_metadata_have_bounded_null_output() {
    let mut session = Session::default();
    let t = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("Empty"));
    let mut e = Engine::new(session);
    let empty = query(&mut e, &[t]);
    unsupported(&empty);
    assert_eq!(empty["lengthSamples"], 0);
    let (mut e, t) = fixture();
    for _ in 0..64 {
        let mut c = e.session().track(t).unwrap().clips()[0].clone();
        c.id = e.session_mut().new_clip_id();
        e.session_mut().track_mut(t).unwrap().playlist_mut().unwrap().clips.push(c);
    }
    let result = query(&mut e, &[t]);
    unsupported(&result);
    assert_eq!(row(&result)["clips"], json!([]));
    assert_eq!(row(&result)["peaks"].as_array().unwrap().len(), 32);
}

#[test]
fn unsupported_clip_metadata_does_not_serialize_nan_or_non_audio_source_ids() {
    let (mut e, t) = fixture();
    e.session_mut().track_mut(t).unwrap().playlist_mut().unwrap().clips[0].stretch = f64::NAN;
    let result = query(&mut e, &[t]);
    unsupported(&result);
    assert_eq!(row(&result)["clips"], json!([]));
    let clip = &mut e.session_mut().track_mut(t).unwrap().playlist_mut().unwrap().clips[0];
    clip.stretch = 1.0;
    clip.content = ClipContent::Audio { source: SourceId(0), offset: 0 };
    let result = query(&mut e, &[t]);
    unsupported(&result);
    assert_eq!(row(&result)["clips"], json!([]));
}

#[test]
fn query_does_not_dirty_document_or_change_selection_transport_rates_or_history() {
    let (mut e, t) = fixture();
    e.session_mut().edit.selection = Range::new(3, 80);
    e.transport.position = 29;
    e.transport.playing = true;
    e.execute("mix.volume", &json!({"track":t.0,"db":-12.0})).unwrap();
    let before = crate::inspect::session(&e, true);
    let revision = e.revision;
    let messages = e.messages.clone();
    let requests = e.transport_requests.clone();
    let result = query(&mut e, &[t]);
    assert_eq!(row(&result)["available"], true);
    assert_eq!(crate::inspect::session(&e, true), before);
    assert_eq!(e.revision, revision);
    assert_eq!(e.messages, messages);
    assert_eq!(e.transport_requests, requests);
}

#[test]
fn default_bins_are_bounded_and_the_epoch_changes_on_reopen() {
    let (mut e, t) = fixture();
    let first = e.execute(INSPECT, &json!({"tracks":[t.0]})).unwrap();
    assert_eq!(first["bins"], 256);
    let next = e.session().clone();
    e.replace_session(next);
    let second = e.execute(INSPECT, &json!({"tracks":[t.0]})).unwrap();
    assert_ne!(first["epoch"], second["epoch"]);
}

#[test]
fn channel_and_work_limits_refuse_expensive_tracks_before_building_spans() {
    let (mut e, t) = fixture();
    let source = e.session().track(t).unwrap().clips()[0].source().unwrap();
    e.session_mut().pool.insert(source, Arc::new(SourceAudio::new(AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.5; 128]; 9] })));
    let result = query(&mut e, &[t]);
    unsupported(&result);
    assert!(row(&result)["reason"].as_str().unwrap().contains("channels"));
    e.session_mut().pool.insert(source, Arc::new(SourceAudio::new(AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.5; 128]; 8] })));
    for _ in 0..32 {
        let mut clip = e.session().track(t).unwrap().clips()[0].clone();
        clip.id = e.session_mut().new_clip_id();
        e.session_mut().track_mut(t).unwrap().playlist_mut().unwrap().clips.push(clip);
    }
    let result = e.execute(INSPECT, &json!({"tracks":[t.0],"bins":1024})).unwrap();
    unsupported(&result);
    assert!(row(&result)["reason"].as_str().unwrap().contains("budget"));
    assert_eq!(row(&result)["peaks"].as_array().unwrap().len(), 1024);
    assert_eq!(row(&result)["clips"].as_array().unwrap().len(), 33);
}

#[test]
fn extreme_stretch_mapping_returns_an_explicit_unavailable_row() {
    let (mut e, t) = fixture();
    e.session_mut().track_mut(t).unwrap().playlist_mut().unwrap().clips[0].stretch = f64::MIN_POSITIVE;
    let result = query(&mut e, &[t]);
    unsupported(&result);
    assert!(row(&result)["reason"].as_str().unwrap().contains("timing"));
}

#[test]
fn inactive_frozen_or_muted_tracks_still_expose_their_original_material() {
    let (mut e, t) = fixture();
    let track = e.session_mut().track_mut(t).unwrap();
    track.inactive = true;
    track.frozen = true;
    track.mixer.mute = true;
    let result = query(&mut e, &[t]);
    assert_eq!(row(&result)["available"], true);
    assert!(row(&result)["peaks"][0][1].as_f64().unwrap() > 0.2);
}
