//! Scoped, atomic insert controls for GazeDeck. No transport or runtime-rate state is edited.
use super::{CommandSpec, always, bad};
use crate::{Engine, Result, TransportRequest, cmd};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use soundcraft_dsp::{ParamInfo, PluginInfo};
use soundcraft_model::{AutomationMode, Insert, Track, TrackId, TrackKind};
use std::collections::{BTreeMap, BTreeSet};

const INSPECT: &str = "mix.effects.inspect";
const SET: &str = "mix.effects.set";
const RESTORE: &str = "mix.effects.restore";
const MAX_SAFE_INTEGER: u64 = (1_u64 << 53) - 1;

pub fn specs() -> Vec<CommandSpec> {
    // History is appended only after an actual change. A query spec avoids generic journaling
    // of no-ops; the change itself still gets normal document undo and journal entries.
    vec![
        cmd!(query "mix.effects.inspect", "Inspect Track Effects", [], None,
            "{tracks?:[id]} — actual Room Reverb, Mod Delay and Chorus insert state and eligibility", always, inspect),
        cmd!(query "mix.effects.set", "Set Track Effects", [], None,
            "{epoch,effect,updates:[{track,slot,expectedInsert,enabled,amount:0..1}]} — atomic CAS for 1..2 tracks; wet mix and bypass only", always, set),
        cmd!(query "mix.effects.restore", "Restore Track Effects", [], None,
            "{epoch,effect,updates:[{track,slot,expectedInsert,restoreInsert}]} — atomic scoped parameter undo; null removes only an owned new insert", always, restore),
    ]
}

#[derive(Clone, Copy, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
enum Effect {
    Reverb,
    Delay,
    Chorus,
}

impl Effect {
    const ALL: [Self; 3] = [Self::Reverb, Self::Delay, Self::Chorus];

    fn info(self) -> &'static PluginInfo {
        match self {
            Self::Reverb => &soundcraft_dsp::plugins::reverb::ROOM_INFO,
            Self::Delay => &soundcraft_dsp::plugins::modulation::DELAY_INFO,
            Self::Chorus => &soundcraft_dsp::plugins::modulation::CHORUS_INFO,
        }
    }

    fn mix(self) -> Option<&'static ParamInfo> {
        self.info().param("mix")
    }

    fn default_amount(self) -> f64 {
        self.mix().map_or(0.0, |param| f64::from(param.default) / 100.0)
    }
}

/// Deliberately narrow public insert view. Full metadata stays on the live Insert.
#[derive(Clone, Debug, PartialEq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct InsertState {
    plugin: String,
    bypass: bool,
    params: BTreeMap<String, f32>,
}

impl From<&Insert> for InsertState {
    fn from(insert: &Insert) -> Self {
        Self { plugin: insert.plugin.clone(), bypass: insert.bypass, params: insert.params.clone() }
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct InspectRequest {
    tracks: Option<Vec<u64>>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SetUpdate {
    track: u64,
    slot: usize,
    #[serde(rename = "expectedInsert")]
    expected: Value,
    enabled: bool,
    amount: f64,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SetRequest {
    epoch: String,
    effect: Effect,
    updates: Vec<SetUpdate>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RestoreUpdate {
    track: u64,
    slot: usize,
    #[serde(rename = "expectedInsert")]
    expected: Value,
    #[serde(rename = "restoreInsert")]
    restore: Value,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RestoreRequest {
    epoch: String,
    effect: Effect,
    updates: Vec<RestoreUpdate>,
}

fn recording(e: &Engine) -> bool {
    e.transport.recording || e.transport_requests.iter().any(|request| matches!(request, TransportRequest::Record))
}

fn track_reason(e: &Engine, track: &Track) -> &'static str {
    if recording(e) {
        "Stop recording before editing effects"
    } else if track.kind != TrackKind::Audio {
        "Track must be audio"
    } else if track.inactive {
        "Track is inactive"
    } else if track.frozen {
        "Track is frozen"
    } else if track.mixer.record_arm {
        "Turn record arm off"
    } else if track.mixer.input_monitor {
        "Turn input monitoring off"
    } else if !matches!(track.mixer.automation_mode, AutomationMode::Off | AutomationMode::Read) {
        "Use automation Off or Read"
    } else if track.automation.iter().any(|lane| !lane.points.is_empty()) {
        "Track contains automation"
    } else {
        ""
    }
}

fn valid_params(effect: Effect, state: &InsertState) -> bool {
    state.plugin == effect.info().id
        && state.params.len() <= effect.info().params.len()
        && state
            .params
            .iter()
            .all(|(key, value)| value.is_finite() && effect.info().param(key).is_some_and(|param| *value >= param.min && *value <= param.max))
}

fn insert_reason(effect: Effect, insert: &Insert) -> &'static str {
    if !insert.active {
        "Insert is inactive"
    } else if insert.state.is_some() || insert.sample.is_some() || !valid_params(effect, &InsertState::from(insert)) {
        "Insert has unsupported state or parameters"
    } else {
        ""
    }
}

/// Unique matching insert, otherwise first empty slot. Duplicate plugins are ambiguous.
fn locate(track: &Track, effect: Effect) -> std::result::Result<Option<usize>, &'static str> {
    let mut found = None;
    for (slot, insert) in track.mixer.inserts.iter().enumerate() {
        if insert.as_ref().is_some_and(|insert| insert.plugin == effect.info().id) {
            if found.is_some() {
                return Err("Multiple matching inserts; choose a single effect in SoundCraft");
            }
            found = Some(slot);
        }
    }
    Ok(found.or_else(|| track.mixer.inserts.iter().position(Option::is_none)))
}

fn effect_value(e: &Engine, track: &Track, effect: Effect) -> Value {
    let (slot, location_reason) = match locate(track, effect) {
        Ok(Some(slot)) => (Some(slot), ""),
        Ok(None) => (None, "No free insert slot"),
        Err(reason) => (None, reason),
    };
    let insert = slot.and_then(|slot| track.mixer.inserts.get(slot)).and_then(Option::as_ref);
    let track_reason = track_reason(e, track);
    let reason = if !track_reason.is_empty() { track_reason } else { location_reason };
    let reason = if reason.is_empty() { insert.map_or("", |insert| insert_reason(effect, insert)) } else { reason };
    let amount = insert.and_then(|insert| insert.params.get("mix")).map_or(effect.default_amount(), |mix| f64::from(*mix) / 100.0);
    json!({"effect":effect,"slot":slot,"insert":insert.map(InsertState::from),
        "enabled":insert.is_some_and(|insert| !insert.bypass && insert.active),
        "amount":amount.clamp(0.0,1.0),"available":reason.is_empty(),"reason":reason})
}

fn snapshot(e: &Engine, tracks: Option<&BTreeSet<TrackId>>) -> Value {
    json!({"version":1,"epoch":e.track_rate_epoch,
        "definitions":Effect::ALL.iter().map(|effect| json!({"effect":effect,"plugin":effect.info().id,
            "param":"mix","defaultAmount":effect.default_amount(),"min":0,"max":1})).collect::<Vec<_>>(),
        "tracks":e.session().tracks.iter().filter(|track| track.kind == TrackKind::Audio && tracks.is_none_or(|ids| ids.contains(&track.id)))
            .map(|track| json!({"track":track.id,"effects":Effect::ALL.iter().map(|effect| effect_value(e,track,*effect)).collect::<Vec<_>>()}))
            .collect::<Vec<_>>()})
}

fn inspect(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: InspectRequest = serde_json::from_value(p.clone()).map_err(|why| bad(INSPECT, format!("invalid request: {why}")))?;
    let ids = if let Some(tracks) = request.tracks {
        if tracks.is_empty() || tracks.len() > 64 {
            return Err(bad(INSPECT, "tracks must contain 1..64 unique audio track ids"));
        }
        let mut ids = BTreeSet::new();
        for track in tracks {
            let id = track_id(INSPECT, track)?;
            if !ids.insert(id) || !e.session().track(id).is_some_and(|track| track.kind == TrackKind::Audio) {
                return Err(bad(INSPECT, "track does not exist, is not audio, or is duplicated"));
            }
        }
        Some(ids)
    } else {
        None
    };
    Ok(snapshot(e, ids.as_ref()))
}

fn track_id(command: &str, raw: u64) -> Result<TrackId> {
    if raw == 0 || raw > MAX_SAFE_INTEGER {
        return Err(bad(command, "track id must be a positive safe integer"));
    }
    Ok(TrackId(raw))
}

fn state(command: &str, effect: Effect, raw: &Value) -> Result<Option<InsertState>> {
    if raw.is_null() {
        return Ok(None);
    }
    let state: InsertState = serde_json::from_value(raw.clone()).map_err(|why| bad(command, format!("invalid insert state: {why}")))?;
    if !valid_params(effect, &state) {
        return Err(bad(command, "insert must match the effect and contain finite, in-range builtin parameters"));
    }
    Ok(Some(state))
}

fn preflight(e: &Engine, command: &str, epoch: &str, count: usize) -> Result<()> {
    if epoch != e.track_rate_epoch {
        return Err(bad(command, "playback session epoch changed; reopen controls"));
    }
    if count == 0 || count > 2 {
        return Err(bad(command, "updates must contain 1..2 unique audio tracks"));
    }
    Ok(())
}

fn target<'a>(e: &'a Engine, command: &str, effect: Effect, id: TrackId, slot: usize) -> Result<Option<&'a Insert>> {
    let track = e.session().track(id).ok_or_else(|| bad(command, "track does not exist"))?;
    let reason = track_reason(e, track);
    if !reason.is_empty() {
        return Err(bad(command, reason));
    }
    let actual_slot = locate(track, effect).map_err(|reason| bad(command, reason))?;
    if actual_slot != Some(slot) {
        return Err(bad(command, "effect slot changed, duplicated, or no free slot remains"));
    }
    let insert = track.mixer.inserts.get(slot).ok_or_else(|| bad(command, "invalid insert slot"))?.as_ref();
    if let Some(insert) = insert {
        let reason = insert_reason(effect, insert);
        if !reason.is_empty() {
            return Err(bad(command, reason));
        }
    }
    Ok(insert)
}

struct Change {
    track: TrackId,
    slot: usize,
    before: Option<Insert>,
    after: Option<Insert>,
}

fn set(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: SetRequest = serde_json::from_value(p.clone()).map_err(|why| bad(SET, format!("invalid request: {why}")))?;
    preflight(e, SET, &request.epoch, request.updates.len())?;
    let mut seen = BTreeSet::new();
    let mut changes = Vec::new();
    for update in request.updates {
        let id = track_id(SET, update.track)?;
        if !seen.insert(id) || !update.amount.is_finite() || !(0.0..=1.0).contains(&update.amount) {
            return Err(bad(SET, "duplicate track or amount outside 0..1"));
        }
        let before = target(e, SET, request.effect, id, update.slot)?;
        let expected = state(SET, request.effect, &update.expected)?;
        if before.map(InsertState::from) != expected {
            return Err(bad(SET, "insert changed; expected state did not match"));
        }
        // Disabled absent effects have no instance or hidden draft state.
        if before.is_none() && !update.enabled {
            continue;
        }
        let mut after = match before {
            Some(insert) => insert.clone(),
            None => {
                let mut insert = Insert::new(request.effect.info().id);
                insert.params = request.effect.info().params.iter().map(|param| (param.id.to_string(), param.default)).collect();
                insert
            }
        };
        after.bypass = !update.enabled;
        let mix = (update.amount * 100.0) as f32;
        let effective = after.params.get("mix").copied().or_else(|| request.effect.mix().map(|param| param.default));
        if effective != Some(mix) {
            after.params.insert("mix".into(), mix);
        }
        if before != Some(&after) {
            changes.push(Change { track: id, slot: update.slot, before: before.cloned(), after: Some(after) });
        }
    }
    commit(e, SET, p, request.effect, changes)
}

fn restore(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: RestoreRequest = serde_json::from_value(p.clone()).map_err(|why| bad(RESTORE, format!("invalid request: {why}")))?;
    preflight(e, RESTORE, &request.epoch, request.updates.len())?;
    let mut seen = BTreeSet::new();
    let mut changes = Vec::new();
    for update in request.updates {
        let id = track_id(RESTORE, update.track)?;
        if !seen.insert(id) {
            return Err(bad(RESTORE, "duplicate track"));
        }
        let before = target(e, RESTORE, request.effect, id, update.slot)?;
        let expected = state(RESTORE, request.effect, &update.expected)?;
        if before.map(InsertState::from) != expected {
            return Err(bad(RESTORE, "insert changed; expected state did not match"));
        }
        let restored = state(RESTORE, request.effect, &update.restore)?;
        let after = match (before, restored) {
            (None, None) => None,
            (Some(before), None) => {
                if e.effect_owned_inserts.get(&(id, update.slot)) != Some(before) {
                    return Err(bad(RESTORE, "only an unchanged insert created by these controls may be removed"));
                }
                None
            }
            (Some(before), Some(restored)) => {
                // Restoring a snapshot can change only the chosen wet mix and bypass.
                let other_params = |params: &BTreeMap<String, f32>| {
                    params.iter().filter(|(key, _)| key.as_str() != "mix").map(|(key, value)| (key.clone(), *value)).collect::<BTreeMap<_, _>>()
                };
                if other_params(&before.params) != other_params(&restored.params) {
                    return Err(bad(RESTORE, "restore may change only wet mix and bypass"));
                }
                let mut after = before.clone();
                after.params = restored.params;
                after.bypass = restored.bypass;
                Some(after)
            }
            (None, Some(_)) => return Err(bad(RESTORE, "restore cannot create an insert; enable the effect instead")),
        };
        if before != after.as_ref() {
            changes.push(Change { track: id, slot: update.slot, before: before.cloned(), after });
        }
    }
    commit(e, RESTORE, p, request.effect, changes)
}

fn commit(e: &mut Engine, command: &str, params: &Value, effect: Effect, changes: Vec<Change>) -> Result<Value> {
    if !changes.is_empty() {
        let before = e.session_arc();
        let session = e.session_mut();
        // Every target and CAS has been validated before this single document mutation.
        for change in &changes {
            if let Some(slot) = session.track_mut(change.track).and_then(|track| track.mixer.inserts.get_mut(change.slot)) {
                *slot = change.after.clone();
            }
        }
        for change in &changes {
            let key = (change.track, change.slot);
            let owned = change.before.is_none() || e.effect_owned_inserts.get(&key) == change.before.as_ref();
            if owned && let Some(after) = &change.after {
                e.effect_owned_inserts.insert(key, after.clone());
            } else {
                e.effect_owned_inserts.remove(&key);
            }
        }
        e.push_undo(if command == SET { "Set Track Effects" } else { "Restore Track Effects" }, before);
        e.journal_append(command, params);
    }
    let mut result = snapshot(e, None);
    result["effect"] = json!(effect);
    result["changed"] = json!(!changes.is_empty());
    result["updated"] = json!(changes.iter().map(|change| change.track).collect::<Vec<_>>());
    result["previous"] = json!(
        changes
            .iter()
            .map(|change| json!({"track":change.track,"slot":change.slot,"insert":change.before.as_ref().map(InsertState::from)}))
            .collect::<Vec<_>>()
    );
    result["after"] = json!(
        changes
            .iter()
            .map(|change| json!({"track":change.track,"slot":change.slot,"insert":change.after.as_ref().map(InsertState::from)}))
            .collect::<Vec<_>>()
    );
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_model::{AutoParam, AutomationLane, ChannelFormat, Clip, Session};
    use soundcraft_time::Range;

    fn fixture() -> (Engine, TrackId, TrackId) {
        let mut session = Session::default();
        let mut ids = Vec::new();
        for name in ["A", "B"] {
            let id = session.add_track(TrackKind::Audio, ChannelFormat::Mono, Some(name));
            let source = crate::io::add_source(
                &mut session,
                name,
                soundcraft_audio_io::AudioBuffer {
                    sample_rate: 48_000,
                    channels: vec![(0..48_000).map(|n| (n as f32 * 0.057).sin() * 0.15).collect()],
                },
                None,
                soundcraft_audio_io::FileFormat::Wav,
            );
            let clip = session.new_clip_id();
            crate::edit::place_clip(&mut session, id, Clip::audio(clip, name, source, 0, 0, 48_000));
            ids.push(id);
        }
        (Engine::new(session), ids[0], ids[1])
    }

    fn request(e: &Engine, effect: Effect, updates: &[(TrackId, bool, f64)]) -> Value {
        json!({"epoch":e.track_rate_epoch,"effect":effect,"updates":updates.iter().map(|(id,enabled,amount)| {
            let track = e.session().track(*id).unwrap();
            let slot = locate(track,effect).unwrap().unwrap();
            json!({"track":id,"slot":slot,"expectedInsert":track.mixer.inserts[slot].as_ref().map(InsertState::from),
                "enabled":enabled,"amount":amount})
        }).collect::<Vec<_>>()})
    }

    fn undo_request(e: &Engine, result: &Value) -> Value {
        json!({"epoch":e.track_rate_epoch,"effect":result["effect"],"updates":result["after"].as_array().unwrap().iter().zip(result["previous"].as_array().unwrap()).map(|(after,before)| {
            json!({"track":after["track"],"slot":after["slot"],"expectedInsert":after["insert"],"restoreInsert":before["insert"]})
        }).collect::<Vec<_>>()})
    }

    #[test]
    fn metadata_comes_from_real_builtin_definitions_and_inspect_is_read_only() {
        let (mut e, a, _) = fixture();
        let before = e.session_arc();
        let result = e.execute(INSPECT, &json!({"tracks":[a]})).unwrap();
        assert_eq!(result["tracks"].as_array().unwrap().len(), 1);
        for (index, effect) in Effect::ALL.into_iter().enumerate() {
            assert_eq!(result["definitions"][index]["plugin"], effect.info().id);
            assert_eq!(result["definitions"][index]["defaultAmount"], effect.default_amount());
            assert_eq!(effect.mix().unwrap().min, 0.0);
            assert_eq!(effect.mix().unwrap().max, 100.0);
            assert_eq!(result["tracks"][0]["effects"][index]["slot"], 0);
        }
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert!(!e.is_dirty());
        assert!(e.journal.is_empty());
    }

    #[test]
    fn atomic_ab_add_preserves_transport_clips_eq_rates_loops_and_other_effects() {
        let (mut e, a, b) = fixture();
        let rate_request = json!({"epoch":e.track_rate_epoch,"loop":{"start":0,"end":48000},"updates":[
            {"track":a,"rate":1.2,"expected":{"rate":1,"revision":0,"loop":null}},
            {"track":b,"rate":0.8,"expected":{"rate":1,"revision":0,"loop":null}}]});
        e.execute("playback.rate.set", &rate_request).unwrap();
        e.transport.position = 945;
        e.transport.playing = true;
        e.session_mut().edit.selection = Range::new(123, 900);
        let mut eq = Insert::new("eq_7band");
        eq.params.insert("output".into(), -3.0);
        e.session_mut().track_mut(a).unwrap().mixer.inserts[0] = Some(eq);
        let delay = request(&e, Effect::Delay, &[(a, true, 0.4)]);
        e.execute(SET, &delay).unwrap();
        let before = e.session().clone();
        let rates = e.playback_rates_snapshot();
        let transport = json!(e.transport);
        let requests = e.transport_requests.clone();
        let revision = e.revision;
        let params = request(&e, Effect::Reverb, &[(a, true, 0.65), (b, true, 0.2)]);
        let result = e.execute(SET, &params).unwrap();
        assert_eq!(result["changed"], true);
        assert_eq!(result["updated"], json!([a, b]));
        assert_eq!(result["previous"][0]["insert"], Value::Null);
        assert_eq!(result["after"][0]["insert"]["params"]["mix"], 65.0);
        assert_eq!(result["tracks"].as_array().unwrap().len(), 2);
        assert_eq!(e.revision, revision + 1);
        let mut expected = before;
        for change in result["after"].as_array().unwrap() {
            let track = TrackId(change["track"].as_u64().unwrap());
            let slot = change["slot"].as_u64().unwrap() as usize;
            expected.track_mut(track).unwrap().mixer.inserts[slot] = e.session().track(track).unwrap().mixer.inserts[slot].clone();
        }
        assert_eq!(*e.session(), expected);
        assert_eq!(e.playback_rates_snapshot(), rates);
        assert_eq!(json!(e.transport), transport);
        assert_eq!(e.transport_requests, requests);
        assert_eq!(e.undo_label(), Some("Set Track Effects"));
    }

    #[test]
    fn stale_second_target_rejects_entire_add_and_restore_batches() {
        let (mut e, a, b) = fixture();
        let mut params = request(&e, Effect::Chorus, &[(a, true, 0.2), (b, true, 0.8)]);
        params["updates"][1]["expectedInsert"] = json!({"plugin":"chorus","bypass":false,"params":{}});
        let before = e.session_arc();
        assert!(e.execute(SET, &params).is_err());
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert!(e.journal.is_empty());
        let params = request(&e, Effect::Chorus, &[(a, true, 0.2), (b, true, 0.8)]);
        let result = e.execute(SET, &params).unwrap();
        let mut undo = undo_request(&e, &result);
        undo["updates"][1]["expectedInsert"]["params"]["mix"] = json!(9.0);
        let before = e.session_arc();
        let journal = e.journal.len();
        assert!(e.execute(RESTORE, &undo).is_err());
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert_eq!(e.journal.len(), journal);
    }

    #[test]
    fn missing_disabled_and_existing_unchanged_do_not_dirty_journal_or_history() {
        let (mut e, a, _) = fixture();
        for amount in [0.0, 0.25, 0.99] {
            let params = request(&e, Effect::Reverb, &[(a, false, amount)]);
            assert_eq!(e.execute(SET, &params).unwrap()["changed"], false);
        }
        assert!(!e.is_dirty());
        assert!(!e.can_undo());
        assert!(e.journal.is_empty());
        e.session_mut().track_mut(a).unwrap().mixer.inserts[0] = Some(Insert::new("room_reverb"));
        let before = e.session_arc();
        let revision = e.revision;
        let params = request(&e, Effect::Reverb, &[(a, true, 0.25)]);
        assert_eq!(e.execute(SET, &params).unwrap()["changed"], false);
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert_eq!(e.revision, revision);
        assert!(!e.can_undo());
        assert!(e.journal.is_empty());
    }

    #[test]
    fn existing_metadata_and_tail_parameters_survive_bypass_and_scoped_undo() {
        let (mut e, a, _) = fixture();
        let mut insert = Insert::new("mod_delay");
        insert.preset = "My delay".into();
        insert.params.insert("time".into(), 570.0);
        insert.params.insert("feedback".into(), 60.0);
        e.session_mut().track_mut(a).unwrap().mixer.inserts[3] = Some(insert.clone());
        let params = request(&e, Effect::Delay, &[(a, false, 0.45)]);
        let result = e.execute(SET, &params).unwrap();
        let after = e.session().track(a).unwrap().mixer.inserts[3].as_ref().unwrap();
        assert!(after.bypass);
        assert_eq!(after.preset, "My delay");
        assert_eq!(after.params["time"], 570.0);
        assert_eq!(after.params["feedback"], 60.0);
        e.transport.position = 9999;
        e.transport.playing = true;
        let undo = undo_request(&e, &result);
        e.execute(RESTORE, &undo).unwrap();
        assert_eq!(e.session().track(a).unwrap().mixer.inserts[3], Some(insert));
        assert_eq!(e.transport.position, 9999);
        assert!(e.transport.playing);
    }

    #[test]
    fn undo_removes_only_owned_new_insert_and_keeps_later_changes() {
        let (mut e, a, _) = fixture();
        let params = request(&e, Effect::Chorus, &[(a, true, 0.7)]);
        let result = e.execute(SET, &params).unwrap();
        let delay = request(&e, Effect::Delay, &[(a, true, 0.4)]);
        e.execute(SET, &delay).unwrap();
        let later = e.session().track(a).unwrap().mixer.inserts[1].clone();
        e.transport.position = 32_000;
        let undo = undo_request(&e, &result);
        e.execute(RESTORE, &undo).unwrap();
        assert!(e.session().track(a).unwrap().mixer.inserts[0].is_none());
        assert_eq!(e.session().track(a).unwrap().mixer.inserts[1], later);
        assert_eq!(e.transport.position, 32_000);
        // The same request cannot remove an effect that predates these controls.
        e.session_mut().track_mut(a).unwrap().mixer.inserts[0] = Some(Insert::new("chorus"));
        let mut unauthorized = request(&e, Effect::Chorus, &[(a, true, 0.5)]);
        let update = unauthorized["updates"][0].as_object_mut().unwrap();
        update.remove("enabled");
        update.remove("amount");
        update.insert("restoreInsert".into(), Value::Null);
        assert!(e.execute(RESTORE, &unauthorized).is_err());
    }

    #[test]
    fn duplicate_full_automation_frozen_record_and_bad_inputs_are_read_only() {
        for condition in [
            "duplicate",
            "full",
            "automation",
            "mode",
            "frozen",
            "inactive",
            "arm",
            "monitor",
            "recording",
            "pending_record",
            "stale",
            "unknown",
            "amount",
            "overflow",
            "duplicate_target",
            "wrong_slot",
            "unknown_param",
            "missing_expected",
            "inactive_insert",
        ] {
            let (mut e, a, _) = fixture();
            let mut params = request(&e, Effect::Reverb, &[(a, true, 0.6)]);
            match condition {
                "duplicate" => {
                    let track = e.session_mut().track_mut(a).unwrap();
                    track.mixer.inserts[0] = Some(Insert::new("room_reverb"));
                    track.mixer.inserts[1] = Some(Insert::new("room_reverb"));
                }
                "full" => e.session_mut().track_mut(a).unwrap().mixer.inserts.fill(Some(Insert::new("gain"))),
                "automation" => {
                    let mut lane = AutomationLane::new(AutoParam::Volume);
                    lane.set_point(0, -4.0);
                    e.session_mut().track_mut(a).unwrap().automation.push(lane);
                }
                "mode" => e.session_mut().track_mut(a).unwrap().mixer.automation_mode = AutomationMode::Touch,
                "frozen" => e.session_mut().track_mut(a).unwrap().frozen = true,
                "inactive" => e.session_mut().track_mut(a).unwrap().inactive = true,
                "arm" => e.session_mut().track_mut(a).unwrap().mixer.record_arm = true,
                "monitor" => e.session_mut().track_mut(a).unwrap().mixer.input_monitor = true,
                "recording" => e.transport.recording = true,
                "pending_record" => e.transport_requests.push(TransportRequest::Record),
                "stale" => params["epoch"] = json!("other"),
                "unknown" => params["unexpected"] = json!(true),
                "amount" => params["updates"][0]["amount"] = json!(1.01),
                "overflow" => params["updates"][0]["expectedInsert"] = json!({"plugin":"room_reverb","bypass":false,"params":{"mix":1e300}}),
                "duplicate_target" => params["updates"] = json!([params["updates"][0], params["updates"][0]]),
                "wrong_slot" => params["updates"][0]["slot"] = json!(1),
                "unknown_param" => params["updates"][0]["expectedInsert"] = json!({"plugin":"room_reverb","bypass":false,"params":{"other":5}}),
                "missing_expected" => {
                    params["updates"][0].as_object_mut().unwrap().remove("expectedInsert");
                }
                "inactive_insert" => {
                    let mut insert = Insert::new("room_reverb");
                    insert.active = false;
                    e.session_mut().track_mut(a).unwrap().mixer.inserts[0] = Some(insert);
                }
                _ => {}
            }
            let before = e.session_arc();
            let revision = e.revision;
            assert!(e.execute(SET, &params).is_err(), "{condition}");
            assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()), "{condition}");
            assert_eq!(e.revision, revision, "{condition}");
            assert!(e.journal.is_empty(), "{condition}");
            assert!(e.effect_owned_inserts.is_empty(), "{condition}");
            if !["stale", "unknown", "amount", "overflow", "duplicate_target", "wrong_slot", "unknown_param", "missing_expected"].contains(&condition)
            {
                let model = e.execute(INSPECT, &json!({})).unwrap();
                assert_eq!(model["tracks"][0]["effects"][0]["available"], false, "{condition}");
                assert!(!model["tracks"][0]["effects"][0]["reason"].as_str().unwrap().is_empty());
            }
        }
    }

    #[test]
    fn same_path_reopen_invalidates_old_controls_and_ownership() {
        let (mut e, a, _) = fixture();
        e.path = Some("same.soundcraft".into());
        let params = request(&e, Effect::Reverb, &[(a, true, 0.6)]);
        e.execute(SET, &params).unwrap();
        let epoch = e.track_rate_epoch.clone();
        e.replace_session(e.session().clone());
        assert_ne!(e.track_rate_epoch, epoch);
        assert!(e.effect_owned_inserts.is_empty());
        assert!(e.execute(SET, &params).is_err());
    }

    fn render(session: &Session) -> Vec<f32> {
        let mut mixer = soundcraft_mix::MixEngine::new(48_000.0, 256);
        let mut out = vec![vec![0.0; 256]; 2];
        let mut samples = Vec::new();
        for pos in (0..48_000).step_by(256) {
            let frames = (48_000 - pos).min(256);
            mixer.render(session, pos as i64, frames, &mut out);
            samples.extend_from_slice(&out[0][..frames]);
        }
        samples
    }

    #[test]
    fn all_three_real_effects_change_synthetic_mix_audio_and_bypass_restores_dry() {
        for effect in Effect::ALL {
            let (mut e, a, b) = fixture();
            e.session_mut().track_mut(b).unwrap().mixer.mute = true;
            let dry = render(e.session());
            let params = request(&e, effect, &[(a, true, 0.85)]);
            e.execute(SET, &params).unwrap();
            let wet = render(e.session());
            assert!(wet.iter().all(|sample| sample.is_finite()));
            let difference = dry.iter().zip(&wet).map(|(a, b)| (a - b).abs()).sum::<f32>() / dry.len() as f32;
            assert!(difference > 0.01, "{} must change rendered audio ({difference})", effect.info().id);
            let params = request(&e, effect, &[(a, false, 0.85)]);
            e.execute(SET, &params).unwrap();
            let bypass = render(e.session());
            assert_eq!(dry, bypass, "{} bypass must restore dry audio", effect.info().id);
        }
    }
}
