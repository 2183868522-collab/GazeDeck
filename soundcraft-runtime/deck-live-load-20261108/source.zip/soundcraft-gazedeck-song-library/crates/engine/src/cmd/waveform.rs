//! Bounded, read-only source envelopes on the engineering timeline for GazeDeck.
//! This is not a mixed/rendered output: channels and overlapping clips are unioned,
//! and clip gain, fades, mute, track gain, inserts and runtime rates are not baked in.
use super::{CommandSpec, always, bad};
use crate::{Engine, Result, cmd};
use serde::Deserialize;
use serde_json::{Value, json};
use soundcraft_model::{Clip, ClipContent, Session, Track, TrackId, TrackKind};
use std::collections::BTreeSet;

const INSPECT: &str = "session.waveform.inspect";
const MAX_SAFE: u64 = (1_u64 << 53) - 1;
const MAX_CLIPS: usize = 64;
const MAX_CHANNELS: usize = 8;
const MAX_WORK: usize = 262_144;

pub fn specs() -> Vec<CommandSpec> {
    vec![cmd!(query "session.waveform.inspect", "Inspect Track Waveforms", [], None,
        "{tracks:[1..2 unique audio ids],bins?:256 (32..1024)} — bounded source envelopes before gain/FX, on the engineering timeline", always, inspect)]
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Request {
    tracks: Vec<u64>,
    bins: Option<usize>,
}

fn safe_position(value: i64) -> bool {
    value.unsigned_abs() <= MAX_SAFE
}

fn metadata_supported(clip: &Clip) -> bool {
    safe_position(clip.start)
        && safe_position(clip.length)
        && clip.length > 0
        && clip.start.checked_add(clip.length).is_some_and(safe_position)
        && safe_position(clip.source_offset())
        && clip.stretch.is_finite()
        && clip.stretch > 0.0
        && clip.source().is_some_and(|source| source.0 > 0 && source.0 <= MAX_SAFE)
        && clip.id.0 > 0
        && clip.id.0 <= MAX_SAFE
}

fn clip_json(clip: &Clip) -> Value {
    json!({"id":clip.id,"name":clip.name,"start":clip.start,"length":clip.length,
        "source":clip.source(),"offset":clip.source_offset(),"stretch":clip.stretch,"muted":clip.muted})
}

fn reason(session: &Session, track: &Track, bins: usize) -> &'static str {
    if track.clips().is_empty() {
        return "No audio clips on the active playlist";
    }
    if track.clips().len() > MAX_CLIPS {
        return "Waveform overview supports at most 64 clips per track";
    }
    let mut work = 0usize;
    for clip in track.clips() {
        if !metadata_supported(clip) {
            return "Clip metadata, timing or source type is unsupported";
        }
        let Some(source) = clip.source() else { return "Active playlist contains a non-audio clip" };
        let Some(audio) = session.pool.get(source) else { return "Audio source is not loaded" };
        if audio.buffer.sample_rate != session.sample_rate.hz() {
            return "Decoded audio sample rate differs from the session";
        }
        let channels = audio.buffer.channels.len();
        if channels == 0 || channels > MAX_CHANNELS || audio.peaks.len() != channels || audio.frames() == 0 {
            return "Decoded source channels or waveform peaks are unavailable";
        }
        if audio.buffer.channels.iter().zip(&audio.peaks).any(|(samples, peaks)| samples.is_empty() || samples.len() != peaks.len_samples()) {
            return "Decoded waveform peaks do not match the loaded source";
        }
        let Some(next) = channels.checked_mul(bins).and_then(|count| work.checked_add(count)) else { return "Waveform query is too complex" };
        work = next;
        if work > MAX_WORK {
            return "Waveform query exceeds the bounded clip/channel budget";
        }
    }
    ""
}

fn union(current: Option<(f32, f32)>, add: (f32, f32)) -> Option<(f32, f32)> {
    Some(current.map_or(add, |(low, high)| (low.min(add.0), high.max(add.1))))
}

fn track_peaks(session: &Session, track: &Track, bins: usize, length: i64) -> std::result::Result<Vec<Option<(f32, f32)>>, &'static str> {
    let mut result = vec![None; bins];
    for (index, value) in result.iter_mut().enumerate() {
        let start = length as f64 * index as f64 / bins as f64;
        let end = length as f64 * (index + 1) as f64 / bins as f64;
        for clip in track.clips() {
            let ClipContent::Audio { source, offset } = clip.content else { continue };
            let from = start.max(clip.start as f64);
            let to = end.min(clip.end() as f64);
            if from >= to {
                continue;
            }
            let audio = session.pool.get(source).ok_or("Audio source became unavailable")?;
            let a = offset as f64 + (from - clip.start as f64) / clip.stretch;
            let b = offset as f64 + (to - clip.start as f64) / clip.stretch;
            if !a.is_finite() || !b.is_finite() {
                return Err("Source timing cannot be represented");
            }
            for (samples, peaks) in audio.buffer.channels.iter().zip(&audio.peaks) {
                // The envelope includes interpolation neighbours conservatively. Parts of a
                // clip outside its decoded source play silence, rather than disappearing.
                let count = samples.len() as f64;
                if a >= count || b <= 0.0 {
                    *value = union(*value, (0.0, 0.0));
                    continue;
                }
                if a < 0.0 || b > (count - 1.0).max(0.0) {
                    *value = union(*value, (0.0, 0.0));
                }
                let first = a.floor().clamp(0.0, count) as usize;
                let last = (b.ceil() + 1.0).clamp(0.0, count) as usize;
                if first < last {
                    let span = peaks.minmax(samples, first, last);
                    if !span.0.is_finite() || !span.1.is_finite() || span.0 > span.1 {
                        return Err("Decoded waveform contains non-finite peaks");
                    }
                    *value = union(*value, span);
                }
            }
        }
    }
    Ok(result)
}

fn inspect(e: &mut Engine, params: &Value) -> Result<Value> {
    let request: Request = serde_json::from_value(params.clone()).map_err(|why| bad(INSPECT, why.to_string()))?;
    let bins = request.bins.unwrap_or(256);
    if !(32..=1024).contains(&bins) || request.tracks.is_empty() || request.tracks.len() > 2 {
        return Err(bad(INSPECT, "Expected 1..2 unique audio tracks and 32..1024 waveform bins"));
    }
    let mut ids = BTreeSet::new();
    for &raw in &request.tracks {
        if raw == 0
            || raw > MAX_SAFE
            || !ids.insert(TrackId(raw))
            || !e.session().track(TrackId(raw)).is_some_and(|track| track.kind == TrackKind::Audio)
        {
            return Err(bad(INSPECT, "Missing, non-audio, unsafe or duplicate target track"));
        }
    }
    let session = e.session();
    let length = session.content_end().max(0);
    if !safe_position(length) {
        return Err(bad(INSPECT, "Project timeline cannot be represented safely"));
    }
    let tracks: Vec<Value> = request
        .tracks
        .iter()
        .filter_map(|raw| session.track(TrackId(*raw)))
        .map(|track| {
            let mut why = reason(session, track, bins);
            if length == 0 && why.is_empty() {
                why = "Project has no positive audio timeline";
            }
            let peaks = if why.is_empty() {
                match track_peaks(session, track, bins, length) {
                    Ok(peaks) => peaks,
                    Err(problem) => {
                        why = problem;
                        vec![None; bins]
                    }
                }
            } else {
                vec![None; bins]
            };
            // An over-budget track is unavailable as a whole. Do not silently omit or
            // invent part of its waveform; keep the response itself bounded too.
            let clips: Vec<Value> = if track.clips().len() <= MAX_CLIPS && track.clips().iter().all(metadata_supported) {
                track.clips().iter().map(clip_json).collect()
            } else {
                Vec::new()
            };
            json!({"track":track.id,"name":track.name,"available":why.is_empty(),"reason":why,
            "clips":clips,"peaks":peaks})
        })
        .collect();
    Ok(json!({"version":1,"epoch":e.track_rate_epoch,"sampleRate":session.sample_rate.hz(),
        "lengthSamples":length,"bins":bins,"kind":"source_envelope_pre_fader","tracks":tracks}))
}

#[cfg(test)]
mod tests;
