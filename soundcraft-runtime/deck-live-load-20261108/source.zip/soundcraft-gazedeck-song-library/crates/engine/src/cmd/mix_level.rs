//! Atomic, epoch-scoped track levels with one native-owned receipt per live gesture.
use super::{CommandSpec, always, bad};
use crate::{Engine, Result, TransportRequest, cmd};
use serde::Deserialize;
use serde_json::{Value, json};
use soundcraft_model::{AutomationMode, Track, TrackId, TrackKind};
use std::collections::BTreeSet;

const INSPECT: &str = "mix.level.inspect";
const SET: &str = "mix.level.set";
const RESTORE: &str = "mix.level.restore";
const MIN_DB: f64 = -144.0;
const MAX_DB: f64 = 12.0;

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!(query "mix.level.inspect", "Inspect Track Levels", [], None,
            "{tracks?:[id]} — audio-track levels and eligibility, without changing playback", always, inspect),
        cmd!(query "mix.level.set", "Set Linked Track Levels", [], None,
            "{epoch,updates:[{track,expectedDb,db}],receipt?:string} — atomic CAS for 1..2 levels; a receipt extends one live gesture", always, set),
        cmd!(query "mix.level.restore", "Restore Linked Track Levels", [], None,
            "{epoch,receipt} — restore the opening levels of one native-owned live gesture", always, restore),
    ]
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct InspectRequest {
    tracks: Option<Vec<u64>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Update {
    track: u64,
    #[serde(rename = "expectedDb")]
    expected: f64,
    db: f64,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SetRequest {
    epoch: String,
    updates: Vec<Update>,
    receipt: Option<String>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RestoreRequest {
    epoch: String,
    receipt: String,
}
#[derive(Clone, Debug)]
struct LevelState {
    track: TrackId,
    before: f32,
    after: f32,
}
#[derive(Clone, Debug)]
pub(crate) struct LevelReceipt {
    token: String,
    targets: Vec<LevelState>,
    // Coalesce native undo only while this remains the latest document mutation.
    // Unrelated user edits between frames create a new native undo boundary.
    last_revision: u64,
    undo_depth: usize,
}

fn valid_db(db: f64) -> bool {
    db.is_finite() && (MIN_DB..=MAX_DB).contains(&db)
}
fn id(command: &str, raw: u64) -> Result<TrackId> {
    if raw == 0 || raw > (1_u64 << 53) - 1 {
        return Err(bad(command, "Track id must be a positive safe integer"));
    }
    Ok(TrackId(raw))
}
fn reason(e: &Engine, track: &Track) -> &'static str {
    if e.transport.recording || e.transport_requests.iter().any(|request| matches!(request, TransportRequest::Record)) {
        "Stop recording before editing levels"
    } else if track.kind != TrackKind::Audio || track.inactive || track.frozen {
        "Use an active, unfrozen audio track"
    } else if track.mixer.record_arm || track.mixer.input_monitor {
        "Turn record arm and input monitoring off"
    } else if !matches!(track.mixer.automation_mode, AutomationMode::Off | AutomationMode::Read)
        || track.automation.iter().any(|lane| !lane.points.is_empty())
    {
        "Disable level automation before editing"
    } else if !valid_db(f64::from(track.mixer.volume_db)) {
        "Level is non-finite or outside -144..12 dB"
    } else {
        ""
    }
}
fn target<'a>(e: &'a Engine, command: &str, id: TrackId) -> Result<&'a Track> {
    let track = e.session().track(id).ok_or_else(|| bad(command, "Target track disappeared"))?;
    let why = reason(e, track);
    if !why.is_empty() {
        return Err(bad(command, why));
    }
    Ok(track)
}
fn snapshot(e: &Engine, ids: Option<&BTreeSet<TrackId>>) -> Value {
    json!({"version":1,"epoch":e.track_rate_epoch,
        "tracks":e.session().tracks.iter().filter(|track|track.kind==TrackKind::Audio && ids.is_none_or(|ids|ids.contains(&track.id)))
            .map(|track|{let why=reason(e,track);let actual=f64::from(track.mixer.volume_db);
                json!({"track":track.id,"db":if actual.is_finite(){actual.clamp(MIN_DB,MAX_DB)}else{0.0},
                    "available":why.is_empty(),"reason":why})}).collect::<Vec<_>>()})
}
fn inspect(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: InspectRequest = serde_json::from_value(p.clone()).map_err(|why| bad(INSPECT, why.to_string()))?;
    let ids = if let Some(tracks) = request.tracks {
        if tracks.is_empty() || tracks.len() > 64 {
            return Err(bad(INSPECT, "Expected 1..64 unique audio tracks"));
        }
        let mut ids = BTreeSet::new();
        for raw in tracks {
            let id = id(INSPECT, raw)?;
            if !ids.insert(id) || !e.session().track(id).is_some_and(|track| track.kind == TrackKind::Audio) {
                return Err(bad(INSPECT, "Missing, non-audio or duplicate track"));
            }
        }
        Some(ids)
    } else {
        None
    };
    Ok(snapshot(e, ids.as_ref()))
}
fn receipt_index(e: &Engine, command: &str, token: &str) -> Result<usize> {
    if token.is_empty() || token.len() > 128 {
        return Err(bad(command, "Invalid level receipt"));
    }
    e.level_receipts
        .iter()
        .position(|receipt| receipt.token == token)
        .ok_or_else(|| bad(command, "Unknown, expired or consumed native level receipt"))
}
fn validate_owned(e: &Engine, command: &str, receipt: &LevelReceipt) -> Result<()> {
    for state in &receipt.targets {
        if target(e, command, state.track)?.mixer.volume_db != state.after {
            return Err(bad(command, "A grouped level changed externally; no tracks modified"));
        }
    }
    Ok(())
}
fn set(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: SetRequest = serde_json::from_value(p.clone()).map_err(|why| bad(SET, why.to_string()))?;
    if request.epoch != e.track_rate_epoch || request.updates.is_empty() || request.updates.len() > 2 {
        return Err(bad(SET, "Epoch changed or expected 1..2 level updates"));
    }
    let index = request.receipt.as_deref().map(|token| receipt_index(e, SET, token)).transpose()?;
    let previous = index.and_then(|index| e.level_receipts.get(index)).cloned();
    if let Some(receipt) = &previous {
        validate_owned(e, SET, receipt)?;
    }
    let mut seen = BTreeSet::new();
    let mut targets = Vec::new();
    for update in request.updates {
        let id = id(SET, update.track)?;
        if !seen.insert(id) || !valid_db(update.expected) || !valid_db(update.db) {
            return Err(bad(SET, "Duplicate target or level outside -144..12 dB"));
        }
        let actual = target(e, SET, id)?.mixer.volume_db;
        if f64::from(actual) != update.expected {
            return Err(bad(SET, "Level changed; expectedDb did not match"));
        }
        targets.push(LevelState { track: id, before: actual, after: update.db as f32 });
    }
    targets.sort_by_key(|state| state.track);
    if let Some(receipt) = &previous
        && receipt.targets.iter().map(|state| state.track).ne(targets.iter().map(|state| state.track))
    {
        return Err(bad(SET, "A live level group cannot change its track set"));
    }
    let changed = targets.iter().filter(|state| state.before != state.after).map(|state| state.track).collect::<Vec<_>>();
    if changed.is_empty() {
        return result(e, &changed, previous.map(|receipt| receipt.token));
    }
    let serial =
        if previous.is_none() { e.level_serial.checked_add(1).ok_or_else(|| bad(SET, "Level receipt sequence exhausted"))? } else { e.level_serial };
    let mut receipt = previous.clone().unwrap_or_else(|| LevelReceipt {
        token: format!("{}-level-{serial:016x}", e.track_rate_epoch),
        targets: targets.clone(),
        last_revision: 0,
        undo_depth: 0,
    });
    for (state, next) in receipt.targets.iter_mut().zip(&targets) {
        state.after = next.after;
    }
    let coalesce = previous.is_some() && receipt.last_revision == e.revision && receipt.undo_depth == e.undo.len();
    commit(e, SET, p, &targets, coalesce);
    receipt.last_revision = e.revision;
    receipt.undo_depth = e.undo.len();
    let token = receipt.token.clone();
    if let Some(index) = index {
        if let Some(owned) = e.level_receipts.get_mut(index) {
            *owned = receipt;
        }
    } else {
        e.level_serial = serial;
        e.level_receipts.push_back(receipt);
        while e.level_receipts.len() > 64 {
            e.level_receipts.pop_front();
        }
    }
    result(e, &changed, Some(token))
}
fn restore(e: &mut Engine, p: &Value) -> Result<Value> {
    let request: RestoreRequest = serde_json::from_value(p.clone()).map_err(|why| bad(RESTORE, why.to_string()))?;
    if request.epoch != e.track_rate_epoch {
        return Err(bad(RESTORE, "Level session epoch changed"));
    }
    let index = receipt_index(e, RESTORE, &request.receipt)?;
    let receipt = e.level_receipts.get(index).ok_or_else(|| bad(RESTORE, "Missing receipt"))?.clone();
    validate_owned(e, RESTORE, &receipt)?;
    let targets = receipt.targets.iter().map(|state| LevelState { track: state.track, before: state.after, after: state.before }).collect::<Vec<_>>();
    let changed = targets.iter().filter(|state| state.before != state.after).map(|state| state.track).collect::<Vec<_>>();
    commit(e, RESTORE, p, &targets, false);
    e.level_receipts.remove(index);
    result(e, &changed, None)
}
fn commit(e: &mut Engine, command: &str, p: &Value, targets: &[LevelState], coalesce: bool) {
    if targets.iter().all(|state| state.before == state.after) {
        return;
    }
    let before = e.session_arc();
    for state in targets.iter().filter(|state| state.before != state.after) {
        if let Some(track) = e.session_mut().track_mut(state.track) {
            track.mixer.volume_db = state.after;
        }
    }
    if !coalesce {
        e.push_undo(if command == SET { "Set Linked Track Levels" } else { "Restore Linked Track Levels" }, before);
    }
    e.journal_append(command, p);
}
fn result(e: &Engine, updated: &[TrackId], receipt: Option<String>) -> Result<Value> {
    let mut value = snapshot(e, None);
    value["changed"] = json!(!updated.is_empty());
    value["updated"] = json!(updated);
    value["receipt"] = json!(receipt);
    Ok(value)
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_model::{AutoParam, AutomationLane, ChannelFormat, Insert, Session};

    fn fixture() -> (Engine, TrackId, TrackId) {
        let mut session = Session::default();
        let a = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("A"));
        let b = session.add_track(TrackKind::Audio, ChannelFormat::Stereo, Some("B"));
        session.track_mut(a).unwrap().mixer.volume_db = -6.0;
        session.track_mut(b).unwrap().mixer.volume_db = -12.0;
        (Engine::new(session), a, b)
    }
    fn request(e: &Engine, updates: &[(TrackId, f64)], receipt: Option<&Value>) -> Value {
        let mut p = json!({"epoch":e.track_rate_epoch,"updates":updates.iter().map(|(id,db)|json!({"track":id,"expectedDb":f64::from(e.session().track(*id).unwrap().mixer.volume_db),"db":db})).collect::<Vec<_>>()});
        if let Some(receipt) = receipt {
            p["receipt"] = receipt["receipt"].clone();
        }
        p
    }
    fn apply(e: &mut Engine, updates: &[(TrackId, f64)], receipt: Option<&Value>) -> Value {
        let p = request(e, updates, receipt);
        e.execute(SET, &p).unwrap()
    }
    fn undo(e: &mut Engine, receipt: &Value) -> Result<Value> {
        e.execute(RESTORE, &json!({"epoch":e.track_rate_epoch,"receipt":receipt["receipt"]}))
    }
    fn levels(e: &Engine, a: TrackId, b: TrackId) -> (f32, f32) {
        (e.session().track(a).unwrap().mixer.volume_db, e.session().track(b).unwrap().mixer.volume_db)
    }

    #[test]
    fn inspect_is_read_only_and_filters_unique_audio_ids() {
        let (mut e, a, b) = fixture();
        let before = e.session_arc();
        let r = e.execute(INSPECT, &json!({"tracks":[b]})).unwrap();
        assert_eq!(r["tracks"], json!([{"track":b,"db":-12.0,"available":true,"reason":""}]));
        assert!(std::sync::Arc::ptr_eq(&before, &e.session_arc()));
        assert!(!e.is_dirty());
        assert!(e.journal.is_empty());
        for tracks in [json!([]), json!([a, a]), json!([0]), json!([9007199254740992_u64]), json!([999999])] {
            assert!(e.execute(INSPECT, &json!({"tracks":tracks})).is_err());
        }
    }
    #[test]
    fn grouped_live_ab_preserves_balance_and_one_native_undo_boundary() {
        let (mut e, a, b) = fixture();
        let r = apply(&mut e, &[(a, -3.0), (b, -9.0)], None);
        let extended = apply(&mut e, &[(b, -6.0), (a, 0.0)], Some(&r));
        assert_eq!(r["receipt"], extended["receipt"]);
        assert_eq!(levels(&e, a, b), (0.0, -6.0));
        assert_eq!(e.undo_history().len(), 1);
        let restored = undo(&mut e, &extended).unwrap();
        assert_eq!(levels(&e, a, b), (-6.0, -12.0));
        assert!(restored["receipt"].is_null());
        assert!(undo(&mut e, &r).is_err());
    }
    #[test]
    fn scoped_restore_keeps_playback_rates_loop_plugins_and_other_track_values() {
        let (mut e, a, b) = fixture();
        e.transport.playing = true;
        e.transport.position = 13579;
        e.track_rates.insert(
            a,
            soundcraft_mix::TrackRateConfig {
                epoch: e.track_rate_epoch.clone(),
                track: a,
                rate: 1.25,
                revision: 9,
                loop_start: 100,
                loop_end: 48000,
            },
        );
        e.session_mut().track_mut(a).unwrap().mixer.inserts[3] = Some(Insert::new("chorus"));
        let rates = e.playback_rates_snapshot();
        let before = json!(e.session());
        let r = apply(&mut e, &[(a, -5.0), (b, -11.0)], None);
        e.transport.position += 960;
        e.session_mut().track_mut(b).unwrap().mixer.pan = vec![0.4, 0.4];
        let r2 = apply(&mut e, &[(a, -2.0), (b, -8.0)], Some(&r));
        assert_eq!(e.undo_history().len(), 2, "an external document edit creates a native undo boundary");
        undo(&mut e, &r2).unwrap();
        assert_eq!(levels(&e, a, b), (-6.0, -12.0));
        assert_eq!(e.transport.position, 14539);
        assert!(e.transport.playing);
        assert_eq!(e.playback_rates_snapshot(), rates);
        let mut after = e.session().clone();
        after.track_mut(b).unwrap().mixer.pan = serde_json::from_value(
            before["tracks"].as_array().unwrap().iter().find(|track| track["id"] == json!(b)).unwrap()["mixer"]["pan"].clone(),
        )
        .unwrap();
        assert_eq!(json!(after), before);
    }
    #[test]
    fn stale_second_track_rejects_entire_batch_without_history_or_receipt() {
        let (mut e, a, b) = fixture();
        let p = request(&e, &[(a, 1.0), (b, 2.0)], None);
        e.session_mut().track_mut(b).unwrap().mixer.volume_db = -8.0;
        let before = json!(e.session());
        assert!(e.execute(SET, &p).is_err());
        assert_eq!(json!(e.session()), before);
        assert!(e.level_receipts.is_empty());
        assert!(e.journal.is_empty());
    }
    #[test]
    fn external_change_prevents_group_extension_and_whole_group_restore() {
        let (mut e, a, b) = fixture();
        let r = apply(&mut e, &[(a, -5.0), (b, -11.0)], None);
        e.session_mut().track_mut(b).unwrap().mixer.volume_db = -8.0;
        let before = json!(e.session());
        let p = request(&e, &[(a, -4.0), (b, -7.0)], Some(&r));
        assert!(e.execute(SET, &p).is_err());
        assert!(undo(&mut e, &r).is_err());
        assert_eq!(json!(e.session()), before);
        assert_eq!(e.level_receipts.len(), 1);
    }
    #[test]
    fn receipt_cannot_change_track_set_or_be_forged() {
        let (mut e, a, b) = fixture();
        let r = apply(&mut e, &[(a, -5.0), (b, -11.0)], None);
        let before = json!(e.session());
        let p = request(&e, &[(a, -4.0)], Some(&r));
        assert!(e.execute(SET, &p).is_err());
        let mut p = request(&e, &[(a, -4.0), (b, -10.0)], None);
        p["receipt"] = json!("unknown");
        assert!(e.execute(SET, &p).is_err());
        assert_eq!(json!(e.session()), before);
    }
    #[test]
    fn noops_do_not_dirty_history_and_net_zero_receipt_remains_usable_until_consumed() {
        let (mut e, a, b) = fixture();
        let none = apply(&mut e, &[(a, -6.0), (b, -12.0)], None);
        assert_eq!(none["changed"], false);
        assert!(none["receipt"].is_null());
        assert!(!e.is_dirty());
        assert!(e.journal.is_empty());
        let r = apply(&mut e, &[(a, -5.0), (b, -11.0)], None);
        let no_change = apply(&mut e, &[(a, -5.0), (b, -11.0)], Some(&r));
        assert_eq!(no_change["receipt"], r["receipt"]);
        assert_eq!(no_change["changed"], false);
        let reset = apply(&mut e, &[(a, -6.0), (b, -12.0)], Some(&r));
        assert_eq!(reset["receipt"], r["receipt"]);
        let out = undo(&mut e, &reset).unwrap();
        assert_eq!(out["changed"], false);
        assert!(out["updated"].as_array().unwrap().is_empty());
        assert!(e.level_receipts.is_empty());
    }
    #[test]
    fn all_requested_tracks_are_owned_even_if_only_one_changes() {
        let (mut e, a, b) = fixture();
        let r = apply(&mut e, &[(a, -5.0), (b, -12.0)], None);
        assert_eq!(r["updated"], json!([a]));
        e.session_mut().track_mut(b).unwrap().mixer.volume_db = -9.0;
        assert!(undo(&mut e, &r).is_err());
        assert_eq!(levels(&e, a, b), (-5.0, -9.0));
    }
    #[test]
    fn invalid_numbers_ids_counts_epochs_and_extra_fields_never_mutate() {
        let (mut e, a, b) = fixture();
        let before = json!(e.session());
        for value in [json!(-144.01), json!(12.01), Value::Null, json!("5"), json!(true)] {
            let mut p = request(&e, &[(a, 1.0)], None);
            p["updates"][0]["db"] = value;
            assert!(e.execute(SET, &p).is_err());
        }
        for raw in [0, 9007199254740992_u64] {
            let mut p = request(&e, &[(a, 1.0)], None);
            p["updates"][0]["track"] = json!(raw);
            assert!(e.execute(SET, &p).is_err());
        }
        for updates in [json!([]), json!([{"track":a,"expectedDb":-6,"db":1},{"track":a,"expectedDb":-6,"db":2}]), json!([{}, {}, {}])] {
            assert!(e.execute(SET, &json!({"epoch":e.track_rate_epoch,"updates":updates})).is_err());
        }
        let mut p = request(&e, &[(a, 1.0), (b, 2.0)], None);
        p["epoch"] = json!("stale");
        assert!(e.execute(SET, &p).is_err());
        let mut p = request(&e, &[(a, 1.0)], None);
        p["arbitrary"] = json!(true);
        assert!(e.execute(SET, &p).is_err());
        assert_eq!(json!(e.session()), before);
        assert!(e.level_receipts.is_empty());
        assert!(e.undo_history().is_empty());
    }
    #[test]
    fn guards_recording_queued_record_inactive_frozen_input_and_automation() {
        for case in 0..9 {
            let (mut e, a, b) = fixture();
            match case {
                0 => e.transport.recording = true,
                1 => e.transport_requests.push(TransportRequest::Record),
                2 => e.session_mut().track_mut(b).unwrap().inactive = true,
                3 => e.session_mut().track_mut(b).unwrap().frozen = true,
                4 => e.session_mut().track_mut(b).unwrap().mixer.record_arm = true,
                5 => e.session_mut().track_mut(b).unwrap().mixer.input_monitor = true,
                6 => e.session_mut().track_mut(b).unwrap().mixer.automation_mode = AutomationMode::Write,
                7 => {
                    let mut lane = AutomationLane::new(AutoParam::Volume);
                    lane.set_point(0, 0.0);
                    e.session_mut().track_mut(b).unwrap().automation.push(lane);
                }
                _ => e.session_mut().track_mut(b).unwrap().kind = TrackKind::Aux,
            }
            let before = json!(e.session());
            let p = request(&e, &[(a, -3.0), (b, -9.0)], None);
            assert!(e.execute(SET, &p).is_err(), "case {case}");
            assert_eq!(json!(e.session()), before);
        }
    }
    #[test]
    fn receipt_epoch_replaced_document_and_bounded_ledger() {
        let (mut e, a, b) = fixture();
        let first = apply(&mut e, &[(a, -5.0)], None);
        for i in 0..64 {
            apply(&mut e, &[(a, if i % 2 == 0 { -4.0 } else { -5.0 })], None);
        }
        assert_eq!(e.level_receipts.len(), 64);
        assert!(undo(&mut e, &first).is_err());
        let latest = apply(&mut e, &[(a, -3.0), (b, -9.0)], None);
        let epoch = e.track_rate_epoch.clone();
        let original = e.session().clone();
        e.replace_session(original);
        assert!(e.level_receipts.is_empty());
        assert_eq!(e.level_serial, 0);
        assert_ne!(e.track_rate_epoch, epoch);
        assert!(undo(&mut e, &latest).is_err());
    }
    #[test]
    fn scalar_levels_are_f32_values_not_independently_clamped() {
        let (mut e, a, b) = fixture();
        let r = apply(&mut e, &[(a, -143.999), (b, 11.999)], None);
        assert_eq!(levels(&e, a, b), (-143.999_f32, 11.999_f32));
        assert_eq!(r["tracks"][0]["db"], json!(f64::from(-143.999_f32)));
        undo(&mut e, &r).unwrap();
        assert_eq!(levels(&e, a, b), (-6.0, -12.0));
    }
}
