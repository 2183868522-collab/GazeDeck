//! Transient, realtime track varispeed. The document and timeline stay untouched.
use crate::{MixEngine, Samples, TrackId};
use std::sync::Arc;

/// One audio-thread configuration. A batch is applied at one callback boundary.
#[derive(Debug, Clone, PartialEq, serde::Serialize)]
pub struct TrackRateConfig {
    pub epoch: String,
    pub track: TrackId,
    pub rate: f64,
    pub revision: u64,
    pub loop_start: Samples,
    pub loop_end: Samples,
}

impl TrackRateConfig {
    pub fn valid(&self) -> bool {
        !self.epoch.is_empty()
            && self.epoch.len() <= 128
            && self.rate.is_finite()
            && (0.5..=2.0).contains(&self.rate)
            && self.loop_start >= 0
            && self.loop_end > self.loop_start
            && self.loop_end < (1_i64 << 53)
    }
}

/// The rate actually consumed by the audio callback and its next material sample.
#[derive(Debug, Clone, PartialEq, serde::Serialize)]
pub struct TrackRateState {
    pub epoch: Arc<str>,
    pub track: TrackId,
    pub rate: f64,
    pub revision: u64,
    pub loop_start: Samples,
    pub loop_end: Samples,
    pub source_position: f64,
}

impl TrackRateState {
    pub(crate) fn wrap(&self, position: f64) -> f64 {
        let start = self.loop_start as f64;
        start + (position - start).rem_euclid((self.loop_end - self.loop_start) as f64)
    }

    pub(crate) fn advance(&mut self, frames: usize) {
        self.source_position = self.wrap(self.source_position + frames as f64 * self.rate);
    }
}

impl MixEngine {
    /// Apply only a wholly valid batch; no clip, fade, plugin or timeline edits.
    /// `ensure_synced` must have run first, as it does in realtime playback.
    pub fn set_track_rates(&mut self, configs: &[TrackRateConfig], position: Samples) -> bool {
        if configs.is_empty()
            || configs.len() > 64
            || configs.iter().any(|c| !c.valid() || !self.strips.contains_key(&c.track))
            || configs
                .iter()
                .enumerate()
                .any(|(i, c)| configs.get(..i).is_some_and(|earlier| earlier.iter().any(|e| e.track == c.track || e.epoch != c.epoch)))
            || configs.iter().any(|config| {
                self.strips.get(&config.track).and_then(|strip| strip.track_rate.as_ref()).is_some_and(|state| {
                    state.epoch.as_ref() == config.epoch
                        && (config.revision < state.revision
                            || config.revision == state.revision
                                && (config.rate != state.rate || config.loop_start != state.loop_start || config.loop_end != state.loop_end))
                })
            })
        {
            return false;
        }
        for config in configs {
            if let Some(strip) = self.strips.get_mut(&config.track) {
                let source_position = strip
                    .track_rate
                    .as_ref()
                    .filter(|state| state.epoch.as_ref() == config.epoch)
                    .map_or_else(|| strip.deck_playback.map_or(position, |deck| deck.position) as f64, |state| state.source_position);
                let mut state = TrackRateState {
                    epoch: Arc::from(config.epoch.as_str()),
                    track: config.track,
                    rate: config.rate,
                    revision: config.revision,
                    loop_start: config.loop_start,
                    loop_end: config.loop_end,
                    source_position,
                };
                state.source_position = state.wrap(source_position);
                strip.track_rate = Some(state);
            }
        }
        true
    }

    /// Only an explicit Locate resets the material position. Stop, resume, rate
    /// changes and the global transport's loop wrap keep its accumulated phase.
    pub fn locate_track_rates(&mut self, position: Samples) {
        for strip in self.strips.values_mut() {
            if let Some(deck) = &mut strip.deck_playback {
                deck.position = position;
            }
            if let Some(state) = &mut strip.track_rate {
                state.source_position = state.wrap(position as f64);
            }
        }
    }

    /// A different document starts with native 1× material playback.
    pub fn clear_track_rates(&mut self) {
        for strip in self.strips.values_mut() {
            if let (Some(deck), Some(rate)) = (&mut strip.deck_playback, &strip.track_rate) {
                deck.position = rate.source_position.floor() as Samples;
            }
            strip.track_rate = None;
        }
    }

    /// Borrowed iterator: publishing callback state needs no temporary allocation.
    pub fn track_rates(&self) -> impl Iterator<Item = TrackRateState> + '_ {
        self.strips.values().filter_map(|strip| strip.track_rate.clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use soundcraft_audio_io::AudioBuffer;
    use soundcraft_model::{ChannelFormat, Clip, Session, SourceAudio, SourceId, TrackKind};
    use std::sync::Arc;

    fn fixture() -> (Session, TrackId, TrackId, MixEngine) {
        let mut session = Session::default();
        let a = session.add_track(TrackKind::Audio, ChannelFormat::Mono, Some("A"));
        let b = session.add_track(TrackKind::Audio, ChannelFormat::Mono, Some("B"));
        let audio = AudioBuffer { sample_rate: 48_000, channels: vec![(0..64).map(|i| i as f32 / 100.0).collect()] };
        session.pool.insert(SourceId(100), Arc::new(SourceAudio::new(audio)));
        for track in [a, b] {
            let id = session.new_clip_id();
            session.track_mut(track).unwrap().playlist_mut().unwrap().clips.push(Clip::audio(id, "ramp", SourceId(100), 0, 0, 64));
        }
        let mut mix = MixEngine::new(48_000.0, 64);
        mix.ensure_synced(&session);
        (session, a, b, mix)
    }

    fn config(track: TrackId, rate: f64, revision: u64) -> TrackRateConfig {
        TrackRateConfig { epoch: "fixture-epoch".into(), track, rate, revision, loop_start: 0, loop_end: 64 }
    }

    fn render(mix: &mut MixEngine, session: &Session, pos: Samples, frames: usize) {
        mix.render(session, pos, frames, &mut vec![vec![0.0; frames]; 2]);
    }

    #[test]
    fn actual_audio_reads_two_independent_rates_without_editing_material() {
        let (session, a, b, mut mix) = fixture();
        let clips = session.tracks.iter().map(|track| track.clips().to_vec()).collect::<Vec<_>>();
        assert!(mix.set_track_rates(&[config(a, 0.5, 1), config(b, 2.0, 1)], 0));
        render(&mut mix, &session, 0, 8);
        for i in 0..8 {
            assert!((mix.strips[&a].buf[0][i] - i as f32 * 0.005).abs() < 1e-6);
            assert!((mix.strips[&b].buf[0][i] - i as f32 * 0.02).abs() < 1e-6);
        }
        let phase = |id| mix.track_rates().find(|state| state.track == id).unwrap().source_position;
        assert_eq!(phase(a), 4.0);
        assert_eq!(phase(b), 16.0);
        assert_eq!(clips, session.tracks.iter().map(|track| track.clips().to_vec()).collect::<Vec<_>>());
    }

    #[test]
    fn global_wrap_and_rate_edits_preserve_phase_and_only_locate_repositions_it() {
        let (session, a, _, mut mix) = fixture();
        assert!(mix.set_track_rates(&[config(a, 1.5, 1)], 0));
        render(&mut mix, &session, 0, 32);
        assert!(mix.set_track_rates(&[config(a, 0.5, 2)], 32));
        render(&mut mix, &session, 0, 8); // Global loop wraps, material does not restart.
        assert!((mix.strips[&a].buf[0][0] - 0.48).abs() < 1e-6);
        let state = mix.track_rates().find(|state| state.track == a).unwrap();
        assert_eq!((state.revision, state.source_position), (2, 52.0));
        mix.reset(); // Pause/stop clears plugin tails, not the deck's source cursor.
        assert_eq!(mix.track_rates().find(|state| state.track == a).unwrap().source_position, 52.0);
        mix.locate_track_rates(4);
        render(&mut mix, &session, 4, 1);
        assert!((mix.strips[&a].buf[0][0] - 0.04).abs() < 1e-6);
        mix.clear_track_rates();
        assert_eq!(mix.track_rates().count(), 0);
    }

    #[test]
    fn material_window_wraps_fractional_neighbors_without_a_silent_tail() {
        let (session, a, _, mut mix) = fixture();
        assert!(mix.set_track_rates(&[config(a, 1.5, 3)], 63));
        render(&mut mix, &session, 63, 4);
        let samples = &mix.strips[&a].buf[0];
        for (actual, expected) in samples.iter().zip([0.63, 0.005, 0.02, 0.035]) {
            assert!((actual - expected).abs() < 1e-6, "{actual} != {expected}");
        }
    }

    #[test]
    fn invalid_or_partial_batches_cannot_change_either_deck() {
        let (_, a, b, mut mix) = fixture();
        assert!(mix.set_track_rates(&[config(a, 1.0, 1), config(b, 1.0, 1)], 9));
        for rate in [f64::NAN, f64::INFINITY, 0.49, 2.01] {
            assert!(!mix.set_track_rates(&[config(a, 1.5, 2), config(b, rate, 2)], 22));
        }
        assert!(!mix.set_track_rates(&[config(a, 1.5, 2), config(TrackId(999), 1.0, 2)], 22));
        assert!(!mix.set_track_rates(&[config(a, 1.5, 2), config(a, 0.5, 2)], 22));
        assert!(!mix.set_track_rates(&[config(a, 1.5, 0)], 22));
        assert!(!mix.set_track_rates(&[config(a, 1.5, 1)], 22));
        assert!(mix.track_rates().all(|state| state.revision == 1 && state.rate == 1.0 && state.source_position == 9.0));
    }

    #[test]
    fn a_new_epoch_never_inherits_the_old_material_cursor_or_applied_revision() {
        let (session, a, _, mut mix) = fixture();
        assert!(mix.set_track_rates(&[config(a, 1.5, 17)], 0));
        render(&mut mix, &session, 0, 16);
        let next = TrackRateConfig { epoch: "new-document".into(), ..config(a, 0.5, 1) };
        assert!(mix.set_track_rates(&[next], 4));
        let actual = mix.track_rates().find(|state| state.track == a).unwrap();
        assert_eq!((actual.epoch.as_ref(), actual.revision, actual.source_position), ("new-document", 1, 4.0));
    }
}
