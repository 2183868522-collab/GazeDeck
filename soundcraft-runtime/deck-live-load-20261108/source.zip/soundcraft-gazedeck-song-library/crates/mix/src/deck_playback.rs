//! Independent, transient material cursors for remote deck transport.
use crate::{MixEngine, Range, Samples, TrackId};

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
pub struct DeckPlayback {
    pub track: TrackId,
    pub paused: bool,
    pub position: Samples,
}

/// The move consumed at a render boundary. Loop wraps still report the signed
/// displacement, so clients can reverse a gesture without rewinding elapsed time.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
pub struct DeckSeekReceipt {
    pub revision: u64,
    pub track: TrackId,
    pub before: Samples,
    pub after: Samples,
    pub delta: Samples,
}

impl MixEngine {
    pub fn seek_deck(
        &mut self,
        track: TrackId,
        offset: Samples,
        revision: u64,
        last_sample: Samples,
        position: Samples,
        project_loop: Option<Range>,
    ) -> Option<DeckSeekReceipt> {
        let strip = self.strips.get_mut(&track)?;
        let deck = strip.deck_playback.get_or_insert(DeckPlayback { track, paused: false, position });
        let (before, after, delta) = if let Some(rate) = &mut strip.track_rate {
            let before = rate.source_position.floor() as Samples;
            rate.source_position = rate.wrap(rate.source_position + offset as f64);
            (before, rate.source_position.floor() as Samples, offset)
        } else if let Some(range) = project_loop.filter(|range| !range.is_empty()) {
            let wrap = |at: Samples| range.start + at.saturating_sub(range.start).rem_euclid(range.len());
            let before = wrap(deck.position);
            (before, wrap(before.saturating_add(offset)), offset)
        } else {
            let end = last_sample.max(0);
            let before = deck.position.clamp(0, end);
            let after = before.saturating_add(offset).clamp(0, end);
            (before, after, after - before)
        };
        deck.position = after;
        Some(DeckSeekReceipt { revision, track, before, after, delta })
    }

    /// Pause or resume existing source cursors, seeding new ones from the current project position.
    pub fn set_deck_playback(&mut self, updates: &[(TrackId, bool)], position: Samples) {
        for &(track, paused) in updates {
            if let Some(strip) = self.strips.get_mut(&track) {
                let deck = strip.deck_playback.get_or_insert(DeckPlayback { track, paused, position });
                deck.paused = paused;
            }
        }
    }

    pub fn clear_deck_playback(&mut self) {
        for strip in self.strips.values_mut() {
            strip.deck_playback = None;
        }
    }

    pub fn cue_loaded_deck(&mut self, track: TrackId, paused: bool) {
        if let Some(strip) = self.strips.get_mut(&track) {
            strip.deck_playback = Some(DeckPlayback { track, paused, position: 0 });
        }
    }

    pub fn deck_playback(&self) -> impl Iterator<Item = DeckPlayback> + '_ {
        self.strips.values().filter_map(|strip| {
            let mut deck = strip.deck_playback?;
            if let Some(rate) = &strip.track_rate {
                deck.position = rate.source_position.floor() as Samples;
            }
            Some(deck)
        })
    }
}
