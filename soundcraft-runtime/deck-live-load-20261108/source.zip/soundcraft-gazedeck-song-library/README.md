# SoundCraft extension source for GazeDeck

This is the GazeDeck integration snapshot based on SoundCraft by the ArtCraft
Team and the SoundCraft contributors. It is a modified research integration,
not an official ArtCraft product or release. Upstream: https://github.com/storytold/soundcraft

The GazeDeck snapshot adds independent deck transport, live track replacement,
playback-rate and local control integration. See apps/soundcraft and crates/.
Source version: 0.17.1. No upstream Git commit is asserted for this local snapshot.

Build the included source, not a fresh upstream checkout:

```sh
cargo build --release -p soundcraft
./target/release/soundcraft --demo --control 7979
```

On Windows use .\target\release\soundcraft.exe --demo --control 7979.
The upstream documentation recommends Rust 1.95 or later for the desktop UI;
the core workspace declares Rust 1.90. A native C/C++ linker/toolchain and the
platform audio/UI dependencies are required. Linux requires ALSA development
headers (libasound2-dev on Debian/Ubuntu). Cargo.lock pins dependencies, including
Git dependencies, which must be downloaded on the first build. A fresh native
build of this release copy has not been verified.

The built-in demo synthesizes its audio. No participant media or private WAV
files are supplied. Start GazeDeck's serve.py separately and explicitly bind
two tracks to A and B in its SoundCraft connection panel.

Original source is MIT OR Apache-2.0; retain LICENSE-MIT, LICENSE-APACHE, NOTICE
and ATTRIBUTION.md. Dependency/assets licenses remain separate. This packaging
does not grant a new license to GazeDeck-authored additions; their terms are
pending. No ArtCraft brand artwork is included. The original brand terms are
retained as a record in docs/brand/LICENSE-brand.txt.

Public-packaging changes: removed eight restricted ArtCraft logo/mark files;
replaced the upstream promotional README with this integration guide; removed
one development-planning document containing machine-specific paths; updated
the attribution inventory. All Rust code, Cargo manifests/lockfile, build code,
and remaining assets are byte-identical to the integration source snapshot.
