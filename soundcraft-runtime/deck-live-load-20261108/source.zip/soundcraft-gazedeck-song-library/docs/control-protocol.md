# Control protocol

SoundCraft can be driven completely by other programs: scripts, test harnesses and AI agents.
Every menu item, button, mouse gesture and keystroke maps to a **command** (or to synthetic
input), and every command is reachable from:

| Surface | How |
|---|---|
| Desktop app control channel | `soundcraft --control <port>` (`0` = pick a free port; printed as `SOUNDCRAFT_CONTROL_PORT=…`) |
| CLI against a running app | `soundcraft-cli app --port <port> <method or command id> [JSON]` (see [cli.md](cli.md)) |
| Headless CLI | `soundcraft-cli run --demo --cmd 'mix.volume={"track":"Kick","db":-6}' --bounce out.wav` |
| MCP (headless) | `soundcraft-cli mcp [--demo]` |
| MCP (bridged to the app) | `soundcraft-cli mcp --connect <port>` |

## Isolated automation profiles

Set `SOUNDCRAFT_CONFIG_DIR` to a fresh directory to isolate UI preferences, `Autosave`, `Presets`, and `logs`.
The nonempty value is used as the complete settings directory, even in portable mode (`portable.txt` beside the executable, which otherwise uses `SoundCraftData` next to it). Unset retains the normal platform paths;
an explicit empty value disables the settings directory instead of falling back to a personal profile. Save synthetic sessions to explicit scratch paths. Do not use `SOUNDCRAFT_NO_PREFS`
when testing preference persistence across restarts.

Run UI acceptance with `--no-audio`. This disables the output player; it does not disable recording
input opened by arm/monitor commands. An automated UI smoke run must never arm a track, enable input
monitoring, or start recording. Control input injects egui events; it does not establish operating-system
input delivery or screen-reader acceptance. Native screenshots use the presented viewport frame.

## Wire format

Newline-delimited JSON over TCP on `127.0.0.1`. One request per line, one reply per line:

```json
{"id": 1, "method": "engine.execute", "params": {"command": "track.new", "params": {"count": 2, "format": "Stereo"}}}
{"id": 1, "ok": true, "result": {"tracks": [12, 13]}}
```

Errors: `{"id": 1, "ok": false, "error": "bad parameters for `mix.volume`: no track named `Nope`"}`.

## Methods

| Method | Params | What it does |
|---|---|---|
| `engine.execute` (alias `command`) | `{command, params}` | Run a command programmatically. **Never opens a dialog**; empty params use defaults or the current selection. |
| `engine.commands` | `{filter?}` | Every command: id, label, menu path, shortcut, params doc, enabled + reason. Includes UI-layer commands (`window.*`). |
| `engine.parity` | `{}` | Parity report against the incumbent's menu catalog. |
| `session.inspect` | `{detail?: "summary"|"full"}` | The document: tracks, clips (with times), inserts (+params when full), sends, routing, automation, markers, groups, busses, sources (`loaded` true when decoded audio is in the pool), selection, zoom (`samples_per_px`, `scroll`), transport, undo label. |
| `ui.inspect` | `{}` | UI state (`window`, panels, dialogs), window size, playing/position, audio device, and `edit_layout` (timeline rect and every track row's rect, for clicking). |
| `ui.set` | any `UiState` fields | e.g. `{"window": "Mix", "narrow_mix": true}`. |
| `ui.menu.list` | `{}` | Every catalog menu path and the command that implements it (or null). |
| `ui.menu.invoke` | `{path}` or `{id}` | Like clicking the menu item: may open its dialog (e.g. `"Track > New..."`). |
| `ui.click` | `{x, y, button?, count?, cmd?, shift?, alt?, ctrl?}` | Synthetic click (window points). The reply is sent only after a UI pass has applied the press/release. |
| `ui.drag` | `{x, y, to_x, to_y, steps?}` | Synthetic drag with the primary button. |
| `ui.scroll` | `{x, y, dx?, dy?, unit?: "point"\|"line", steps?, cmd?, shift?, alt?, ctrl?}` | A two-finger trackpad swipe over `(x, y)`: `dx`/`dy` points spread over `steps` frames (default 8). Positive values move the content right/down (natural scrolling). `unit: "line"` sends mouse-wheel notches instead. With `cmd` it zooms; with `shift` it scrolls sideways. Point scrolling is trackpad-like: egui 0.37 scroll areas may rubber-band at an edge and spring back after the gesture, so a script that needs an exact final offset should use `unit: "line"` or drive the target with a command. |
| `ui.zoom` | `{x, y, factor, steps?}` | A trackpad pinch around `(x, y)`: `factor` > 1 spreads the fingers (zooms in). |
| `ui.move` | `{x, y}` | Move the pointer. |
| `ui.key` | `{key, cmd?, shift?, alt?, ctrl?}` | Key press (`Space`, `Enter`, `A`, `F7`, `=`…). |
| `ui.text` | `{text}` | Type text into the focused field. At most 64 KiB of UTF-8 text per request. |
| `ui.screenshot` | `{path?}` | PNG of the window (base64 in `png_base64` when no path). Exactly one reply per request. A request is bound to the window geometry, focus state and open session it was admitted for. A geometry or DPI change is retried within its 8 s deadline, then fails `screenshot stale`; a change of focused window or of the open document cancels it (`screenshot canceled: focus changed` / `... the session changed`) because those pixels must not be reported as a capture of the new state. It can also fail `screenshot queue full` (8 pending, 4 in flight), `screenshot too large` (64 MiB per image, 192 MiB aggregate **encoding peak**), `screenshot path longer than 4096 bytes`, or `screenshot unavailable: the window has no capturable size yet` (a first request before any window geometry is known, e.g. minimised before the first paint). Each request reserves its own worst-case encode peak — the captured RGBA image plus the raw copy, PNG buffer and base64 text built during encoding — so several small captures cannot retain or encode full-size images past the aggregate. The callback never writes a file: encoding and writing happen after collection, and a result arriving after the deadline returns `screenshot timed out` without creating the file. A native hidden/minimised window is asked for an explicit paint; browser hidden tabs cannot paint on request and time out. |
| `app.quit` | `{}` | Quit. |

Scripted input (`ui.click`, `ui.drag`, `ui.scroll`, `ui.zoom`, `ui.key`, `ui.text`, `ui.move`) queues at most 4096 waiting events; a request that would exceed that bound fails with `synthetic input queue full` instead of growing the queue. A gesture's reply is delivered only after a UI pass has applied all of its events. Requests that follow it on the same connection (inspect, engine commands, screenshots) are therefore ordered after the gesture; requests already queued behind an undelivered gesture wait as well. If no UI pass can deliver the gesture within 15 s, it is canceled with `synthetic input was not delivered` and the request chain continues. Scripted input is automation, not a clipboard action: copy/selection commands it triggers are not published to the OS clipboard or PRIMARY selection.

## Read-only track waveform overview (local GazeDeck extension, 2026-11-07)

`engine.execute` with `session.waveform.inspect` takes exactly
`{tracks:[id] or [id,id], bins?:256}`. Targets are explicit, unique, positive
JavaScript-safe audio-track IDs. `bins` is an integer in 32–1024; other fields are
rejected. It returns:

```json
{"version":1,"epoch":"opaque-session-token","sampleRate":48000,"lengthSamples":192000,"bins":256,"kind":"source_envelope_pre_fader","tracks":[{"track":11,"name":"Deck A","available":true,"reason":"","clips":[{"id":15,"name":"Original material","start":0,"length":192000,"source":8,"offset":0,"stretch":1.0,"muted":false}],"peaks":[[0.0,0.2],null]}]}
```

The example shortens `peaks`; the real array has exactly `bins` entries. Targets
retain request order. Every bin occupies its uniform interval on the engineering
timeline `[0,lengthSamples)`, with sample positions at `sampleRate`. `epoch` is the
same open-document token as `playback.rate.inspect`, changing even on reopening
the same path. The active playlist supplies the clip metadata. Negative clip
starts and source offsets are retained as signed, safe integers.

This is a **source envelope**, not an audible master or per-track mixed output.
Decoded-channel min/max spans and overlapping clips are unioned rather than
summed. Stored source offsets and clip stretch map timeline position `t` to
`offset + (t-start)/stretch`; interpolation neighbours are conservatively included.
Sources have already been decoded/resampled to the session rate. Reversed audio
uses its rendered source; there is no separate reverse playback flag. Gain,
fades, envelopes, clip/track mute, track levels, EQ, effects and runtime varispeed
are not baked into the waveform. Muted clips remain visible and carry `muted`.
Finite floating-point headroom above ±1 is retained for clients to display.

`null` is a timeline gap with no clip; `[0,0]` is digital silence or the silent
part of an existing clip beyond its loaded source. Offline media is not silently
treated as silence. A track with missing media, mismatched decoded sample rate,
unsupported timing/channel data, non-finite peaks or excessive complexity has
`available:false`, a nonempty `reason`, and all-null peaks. Empty tracks are also
unavailable. Structurally valid metadata is still returned for offline media;
invalid/non-audio metadata or more than 64 clips returns `clips:[]` as a whole,
with an unavailable reason. Each source is limited to 8 channels and the query
budget is 262,144 bin × clip-channel combinations per track.

The command uses only cached `SourceAudio.peaks` and its loaded samples, never
opens a path, decodes media or renders/processes audio. It does not change the
session, dirty state, selection, history, playback, source loops or rates. Clients
must display unavailable reasons explicitly and obtain actual runtime source
cursors separately from `ui.inspect.track_rates`, verifying their epoch.

## GazeDeck runtime track varispeed extension (version 1)

This local extension adds real audio playback rates without editing clip length, stretch,
fades, source files, the project tempo map, selection or document undo history. Rates are
runtime state and reset to 1.0 whenever a document is opened, created or reverted. Opening
the same path again produces a new opaque `epoch`, invalidating earlier requests.

Through `engine.execute`, `playback.rate.inspect {"tracks":[11,14]}` returns:

```json
{"version":1,"epoch":"opaque-session-token","policy":"fixed_seconds_independent_source_wrap","min_rate":0.5,"max_rate":2.0,"tracks":[{"track":11,"rate":1.0,"revision":0,"loop":null},{"track":14,"rate":1.0,"revision":0,"loop":null}]}
```

Omitting `tracks` inspects every audio track. `session.inspect` includes the same metadata
at `playback_rates` and a per-track record at `tracks[].playback_rate`. Those records describe
the requested state. The realtime host reports its audio-thread applied state separately in
`ui.inspect.track_rates`, including each source playback position. The accompanying
`ui.inspect.track_rates_epoch` and that array are read from one consistent audio-callback
snapshot; the epoch is initially null until a configuration or clear is consumed. A client
must confirm the applied epoch, rate and revision before displaying a successful audio change.

`playback.rate.set` takes one atomic compare-and-set batch, with sample positions at the
session sample rate:

```json
{"epoch":"opaque-session-token","loop":{"start":0,"end":710322},"updates":[{"track":11,"rate":1.1,"expected":{"rate":1.0,"revision":0,"loop":null}},{"track":14,"rate":0.9,"expected":{"rate":1.0,"revision":0,"loop":null}}]}
```

Every target, expected rate/revision/boundary, epoch and range is validated before any track
changes. Rates are finite values in 0.5–2.0; only active, unfrozen audio tracks with decoded
audio in the requested interval are accepted. Recording refuses changes. The response uses
the inspect shape for the named tracks, plus `changed`; each changed track gains one revision.
The whole batch is dispatched to the audio thread together. An unchanged batch queues nothing.

`playback.rate.clear {"epoch":"opaque-session-token"}` removes **all** runtime track
rates and independent source loops, restoring native 1x playback. Playback must be paused
and recording stopped; an incorrect epoch or unknown field is rejected without changes.
The operation does not seek, start playback, alter document selection, disable the global
transport loop, edit clips or affect document undo history. It rotates the epoch even when
the runtime table was already empty, so earlier control popups cannot re-enable canceled
loops. The response is the all-audio-track inspect shape with the new epoch and `changed:true`;
all tracks have `rate:1.0`, `revision:0` and `loop:null`. The audio thread removes queued rate
batches and applied runtime states; confirm an empty `ui.inspect.track_rates`,
with `ui.inspect.track_rates_epoch` equal to the newly returned epoch,
before reporting audio completion. Enqueuing the clear does not publish this acknowledgement;
only consumption by the callback does so. Unlike applying a non-native rate, clearing is
also available when the player is running its fallback silent clock. To cancel
both loop layers, clear these runtime loops while paused and separately disable the global
transport loop. Clearing retains the paused engineering playhead but drops independent source
phase; subsequent native playback follows that engineering playhead.

The source-loop interval is fixed in **sample seconds**, exclusive of its end, independently
of the editable mouse selection. Source material advances at its track's rate and wraps inside
that interval. Updating a rate with the same interval retains the current source phase. A
different interval requires paused playback: within the same epoch it retains the current
source phase and wraps that phase into the new interval. It does not seek or start the project
transport. An explicit clear or a new document removes runtime rates and returns to native 1x;
the next initial configuration starts its source phase from the current engineering timeline
position, wrapped into its interval. Pause/resume retains source phase, and an explicit seek
relocates it. A transport loop wrap is distinct from an explicit seek and retains source phase.

The rate changes pitch (varispeed); it is not a pitch-preserving render. Source BPM is user
metadata and must not be inferred from the project tempo. To undo a rate edit, send another
CAS batch with only the old rates and the current expected revisions; do not use document
Undo, restore a historical transport timestamp, or replay an unconfirmed mutation.

## Independent Deck playback (local GazeDeck extension, 2026-11-07)

- `playback.deck.inspect {tracks?:[id]}` returns `{version:1,epoch,playing,tracks:[{track,paused,position}]}`. The paused flag is the Deck state and `playing` is the project transport. A managed track reports its callback-confirmed position in project samples, or `null` until the audio callback confirms the current state. An unmanaged track follows the project position.
- `playback.deck.set {epoch,track,paused,expected_paused,expected_playing,peer?:id}` changes the selected audio track at a render boundary. Playing from idle starts project transport, with the other bound Deck parked first when `peer` is supplied. A running project keeps its transport state when a Deck pauses or resumes. The desktop host requires an active audio output.
- `playback.deck.seek {epoch,track,offset_samples}` queues a move for one audio track and returns `{epoch,track,revision}`. The nonzero signed offset is limited to 30 seconds in project samples. The track and project can be playing or paused. The track's own material loop takes precedence over the active project loop. With no loop, the move stops at the project start or the target's final audio sample. The audio callback publishes `last_seek:{revision,track,before,after,delta}` via `playback.deck.inspect`, which advertises `seek_supported:true`. A loop wrap reports the full signed displacement as `delta`, while a clamped move reports only the applied displacement. Use the matching revision to verify execution before issuing another move.

A paused Deck retains its own material position, including a fractional position under varispeed. Resume continues there. Its existing inserts can finish processing their tails. A fixed source loop takes priority over the project loop. An explicit project locate repositions both Decks. Global transport pause and play retain the Deck states, while opening another document or replacing the audio device clears them. The project transport's explicit selection end still applies. Deck controls are kept in runtime memory, outside the session document.

## Scoped track effects (local GazeDeck extension, 2026-11-07)

`mix.effects.inspect {"tracks":[1,2]}` is read-only; omit `tracks` to return every audio
track, including audio tracks whose controls are unavailable. Other track kinds are omitted.
The result is `{version:1,epoch,definitions,tracks}`. `epoch` is the current open-document
playback epoch, and changes even when reopening the same session path. `definitions` contains
`{effect,plugin,param,defaultAmount,min:0,max:1}` for these actual builtin plugins:

| Effect | Plugin | Wet parameter | Native range | Default amount |
| --- | --- | --- | --- | --- |
| `reverb` | `room_reverb` | `mix` | 0–100 percent | 0.25 |
| `delay` | `mod_delay` | `mix` | 0–100 percent | 0.30 |
| `chorus` | `chorus` | `mix` | 0–100 percent | 0.50 |

Each track is `{track,effects:[{effect,slot,insert,enabled,amount,available,reason}]}`.
`insert` is null or exactly `{plugin,bypass,params}`, with the complete stored parameter map.
An absent effect reports its builtin default amount, `enabled:false`, and the first empty
insert slot. A unique existing effect keeps its own slot. Duplicate matching plugins or a full
insert rack with no matching plugin report `slot:null` and an unavailable reason. Existing
ineligible audio tracks retain their unique insert state for readback. An available row has an
empty reason. Controls require active, unfrozen audio tracks, record arm and input monitoring
off, automation Off or Read, and no automation breakpoints anywhere on the track. Active or
queued recording blocks changes. Inactive inserts, opaque builtin state and unsupported or
out-of-range parameters are read-only.

`mix.effects.set {"epoch":"…","effect":"reverb","updates":[{"track":1,"slot":0,
"expectedInsert":null,"enabled":true,"amount":0.4}]}` atomically validates one or two unique
targets before changing the document once. `expectedInsert` is required, including explicit
null before creation. Copy the insert state from fresh inspection. Numbers compare as native
f32 values; wet amount is converted by `(amount * 100.0) as f32`. Unknown fields, nonfinite or
out-of-range numbers, stale epochs, moved slots, duplicates and stale insert states reject the
whole batch. A new instance can occupy only the first empty slot and initializes every builtin
parameter default. A disabled absent effect is always a no-op and has no hidden amount state.
On an existing insert, only bypass and wet mix may change. Preset name and other metadata are
preserved. Sparse parameter maps retain a missing wet key when the effective default already
equals the requested amount. Bypassing preserves effect parameters and the existing instance.

`mix.effects.restore {"epoch":"…","effect":"reverb","updates":[{"track":1,"slot":0,
"expectedInsert":{"plugin":"room_reverb","bypass":false,"params":{}},
"restoreInsert":null}]}` uses the same atomic guards. Both insert fields are required.
Use each confirmed mutation's `after` state as expected and its `previous` state as restore.
A non-null restore may alter only this effect's wet mix and bypass; every other stored parameter
must match. Null may remove only an insert created by these controls whose complete internal
metadata still matches the last control-owned state. An externally changed or pre-existing
insert cannot be removed by this command. Ownership is cleared on session replacement.

Both mutations return the **all-audio-track** inspect model plus `effect`, `changed`,
`updated:[trackId]`, `previous:[{track,slot,insert}]`, and `after:[{track,slot,insert}]`.
The receipt arrays contain changed targets only. After removal, the model's proposed first
empty slot may differ from the receipt's removed slot. A no-op leaves revision, dirty state,
global undo and journal untouched. Actual changes create one document undo point and journal
entry. Parameter undo should use `mix.effects.restore`, avoiding a whole-document rollback.
No effect command edits or queues transport state, elapsed position, loop boundaries, runtime
rates, clips, EQ or unrelated effects. A receipt confirms native document state; it is not an
audio-device acknowledgment. Synthetic-audio regression tests exercise these exact inserts
through `MixEngine` and verify wet audio differs and bypass returns dry audio.

## Atomic tone presets (local GazeDeck extension, 2026-11-07)

`mix.tone.inspect {"tracks":[1,2]}` is read-only; omit `tracks` for all audio tracks.
It returns `{version:1,epoch,tracks:[{track,available,reason,tone,inserts}]}`. `inserts`
is the ordered complete occupied-slot view `{slot,plugin,bypass,params}`. Tone is:

```json
{"eq":{"enabled":true,"low":3,"mid":-2,"high":1},"effects":{
  "reverb":{"enabled":true,"amount":0.42},
  "delay":{"enabled":false,"amount":0.3},
  "chorus":{"enabled":true,"amount":0.31}}}
```

The three EQ gains are `eq_7band`'s low shelf, mid peak, and high shelf gains in
−24..24 dB; `enabled` is the inverse of bypass. FX use the builtin IDs and 0..1
wet mixes above. No EQ frequencies, Q, other filter gains, effect time/rate/feedback,
volume, BPM, source rates, transport, clips, or loop bounds belong to a tone preset.
Ineligible rows still return bounded, finite tone values for display; `available:false`
always prohibits apply. Absent EQ is disabled with zero gains; absent FX are disabled
with the actual builtin default mixes. Readback of invalid native tone parameters is
clamped/defaulted on an unavailable row, never silently admitted for editing.

`mix.tone.apply {"epoch":"…","updates":[{"track":1,"expectedInserts":[…],"tone":{…}}]}`
preflights one or two unique tracks and every insert-chain CAS before any mutation.
It rejects stale epochs, unsupported targets/automation/recording, ambiguous duplicate
tone plugins, opaque/inactive tone inserts, invalid numbers and insufficient free slots.
New enabled plugins take distinct empty slots without moving/replacing existing inserts;
all native defaults initialize newly created instances. Missing disabled plugins remain
absent and their requested inactive gain/mix values have no hidden state. Existing
disabled plugins may update these exposed gains/mixes while staying bypassed. Other
parameters, metadata and plugin order remain unchanged, including implicit sparse defaults.

The result is the full inspect model plus `changed`, `updated:[trackId]`, and
`receipt:string|null`. A changed operation creates one undo/journal entry and a native
receipt; a no-op leaves undo/journal/dirty state untouched. Receipts are opaque, bounded
to the latest 64 changed tone operations, and cleared on open/new (including reopening
the same project). They are not project-persistent preset files.

`mix.tone.restore {"epoch":"…","receipt":"…"}` consumes a receipt only after all
changed slots still exactly match their native post-apply state, including metadata.
It restores just those native-owned changes as one batch. Newly created inserts can
therefore be safely removed, but the client cannot request arbitrary insert deletion.
Changes in unrelated slots and naturally elapsed playback time survive. Changed slots
edited externally cause whole-batch rejection; consumed/forged/expired receipts reject.
Prior scoped-FX ownership is reinstated, supporting chained tone/FX parameter undo.
Receipt confirmation describes native document parameters, not an audio-callback ACK.

## GazeDeck local linked-level extension

`mix.level.inspect {"tracks":[11,14]}` reads active audio-track levels without
changing audio. Omit `tracks` to inspect all audio tracks; a filter accepts 1–64
distinct positive safe-integer IDs. The model is `{version:1,epoch,tracks:[{track,
db,available,reason}]}`. `epoch` identifies the open native document, including
reopening the same path. Levels are native float32 dB values promoted to JSON
numbers. An unavailable row is read-only and reports its reason.

`mix.level.set {"epoch":"…","updates":[{"track":11,"expectedDb":-6,
"db":-3},{"track":14,"expectedDb":-12,"db":-9}]}` performs one atomic
compare-and-set over 1–2 distinct audio tracks. Every target and expected level is
validated before either level changes. Both numbers must be finite and within
−144…+12 dB; values are not independently clipped. The caller can use a common
offset with the intersection of both tracks' ranges to preserve their balance.
Recording or queued Record, inactive/frozen tracks, record arm, input monitoring,
and non-read/off automation or any automation points reject the entire batch.
No transport, mute, pan, inserts, source-loop or runtime-rate state changes.

The reply adds `{changed,updated,receipt}` to the full model. A first actual
change creates a native-owned, session-scoped group receipt. `updated` names only
tracks whose level changed. An initial no-op has `receipt:null`. To continue the
same live gesture, pass the returned `receipt` with subsequent set requests. A
continuation must name the same target set, and every current level must still
match both its expectedDb and the group's last native after value. It keeps the
earliest opening levels and replaces only the latest after values; a no-op
continuation retains the same receipt. Consecutive frames share one native undo
point; an unrelated document mutation starts a new native undo boundary.

`mix.level.restore {"epoch":"…","receipt":"…"}` checks every grouped target
against its latest native after value, then restores the opening levels as one
atomic batch and consumes the receipt. A group returned to its opening values
may be restored as a no-op, which still consumes its token. Forged, consumed,
expired or changed-target receipts reject without partial writes. The ledger is
bounded to 64 groups and cleared when the document is replaced. Groups contain
only level values and never enter `.scraft` files; ordinary level changes remain
normal saved mixer parameters. Receipt readback confirms native document values,
not an audio-callback acknowledgement. Lost replies must not be automatically
replayed; inspect/reconnect before another explicit gesture.

## Positions and references

- Tracks: id (number) or name (`"Kick"`).
- Clips: id (from `session.inspect`).
- Positions: samples (`96000`), seconds (`{"seconds": 2.5}`), or a time string in any timebase,
  optionally prefixed: `"bars_beats:5|1|000"`, `"min_secs:0:12.500"`, `"timecode:00:00:10:00"`,
  `"samples:48000"`.
- Ranges: `start` + `end` (or `start` + `length`); omitted = the current edit selection.

## Examples

```sh
P=$(soundcraft --demo --control 0 | sed -n 's/SOUNDCRAFT_CONTROL_PORT=//p')   # or read stderr
soundcraft-cli app --port $P mix.solo '{"track":"Bass"}'
soundcraft-cli app --port $P transport.play
soundcraft-cli app --port $P ui.screenshot '{"path":"/tmp/shot.png"}'
soundcraft-cli app --port $P ui.menu.invoke '{"path":"Track > New..."}'
```

Offscreen (no window): `cargo run -p soundcraft-ui-egui --example ui_shot -- out.png script.jsonl`,
where each script line is a request (`{"method": …, "params": …}`), `{"shot": "path.png"}` or
`{"steps": n}`. Use `--system-theme light|dark|none` to supply the initial OS appearance, and
script events such as `{"system_theme": "dark"}` to change it on subsequent frames.

Appearance defaults to Dark. `ui.theme {"mode":"system"}` follows the appearance supplied by
the native or web integration at launch and on later frames, while the saved choice stays System.
When the integration cannot report an appearance, as on Linux, System reads the desktop's
settings portal (`org.freedesktop.appearance` `color-scheme`) and follows its changes; without
a portal answer it uses Dark. Manual Light and Dark stay fixed when the OS appearance changes.
An offscreen render without `--system-theme` supplies no OS appearance and therefore resolves
System to Dark, or on Linux to the desktop's portal setting when one is available.

`view.scroll_into_view {"track":"Bass"}` (a track id or name; without it, the first selected
track) brings the track to the top of the Edit window and the left of the Mix window, the same as
Scroll Into View in the track name menu. A window not on screen catches up when it is next shown.

## Panel docking

Tracks and Groups, Clips, MIDI Editor, Memory Locations, and Undo History use movable panels. Commands target the active Edit or Mix view; floating panels stay inside the current viewport. Edit and Mix retain separate arrangements; Clips and MIDI Editor belong to Edit. Transport, plug-in, and specialist utility windows retain their existing hosts. The document/session view is protected.

The Edit window starts with Tracks and Groups in a 168-point column in a dock at the left edge, Clips in a 230-point column in a dock at the right edge, and the MIDI Editor under the session view between them. Both docks run the window's full height. Mix starts with Tracks and Groups docked at its left edge. Memory Locations and Undo History float. A dock column stacks tab groups top to bottom: a panel dropped on a group's middle joins it as a tab, on its upper or lower third stacks a new group above or below it, and at a column's edge makes a new column. A panel dropped at an empty window edge makes a dock there. Layouts, active tabs, panel visibility, and floating rectangles are saved with the app's existing UI preferences. These operations do not edit document contents.

Panel IDs: `tracks`, `clips`, `midi`, `memory`, `history`. The protected center is `canvas`.

`ui.dock` accepts `operation` and `panel`. Operations are `open`, `close`, `activate`, `float` (with finite positive `rect: [x, y, width, height]`), or `move` (with `target` and `zone: tab|center|left|right|top|bottom|above|below`; PascalCase names such as `Left` also parse). `open` and `activate` show a hidden panel at its saved location and bring a visible panel to the front. A panel with no saved location, or whose saved anchor cannot be restored, opens at its default place: Tracks and Groups and Clips join their dock's first group, or make that dock again at its default width when it is gone; the MIDI Editor opens under the session view; Memory Locations and Undo History float at their default rectangles. Center and `tab` group with the target; side zones split beside it; `above` and `below` stack the panel in a new group above or below a floating target's group. `ui.dock.reset` restores the default arrangement. Invalid moves return an error without changing the layout.

Invoke these UI commands through `engine.execute`, for example `{"command":"ui.dock","params":{"operation":"float","panel":"tracks","rect":[100,100,320,440]}}`.

Advanced `ui.dock` operations use the same validated transaction as pointer gestures:
`moveFloating` updates `rect`, `resizeSplit` accepts a boolean child `path` and
`size` (`{"Ratio":0.5}`, `{"FixedFirst":280}`, or `{"FixedSecond":280}`),
`setStackOpen` takes `open`, and `resizeStack` takes a point `height` or null.
A center `move` can include `before` (panel ID or null to append) for tab order.
The equivalent `{"action": ...}` form accepts a serialized shared docking action;
this is also the form emitted by the renderer. Protected-canvas and app-specific panel
rules apply equally to both forms.

The saved UI preferences and window configurations carry `docking_version`. Settings with no
version, or an older one, hold the split-frame layouts of earlier releases: they load with the
default Edit and Mix layouts and keep every other setting.
